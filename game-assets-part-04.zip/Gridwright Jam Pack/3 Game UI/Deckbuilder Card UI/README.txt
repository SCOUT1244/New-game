GRIDWRIGHT DECKBUILDER CARD UI - FREE SAMPLE  v1.0
==================================================

50 sprites from Gridwright Deckbuilder Card UI: one common card of each type, a rare and an upgraded attack card, the card back,
two glows, panels, buttons, the END TURN button, the HP bar with fills and the block badge, the draw and discard piles, a relic
slot, the energy orb (4 frames + empty), 5 intents, 4 status icons, 6 relics and 4 map nodes with a path piece.
Same grid, same file names and same licence as the full pack (260 sprites).

LICENCE: the same as the full pack (LICENSE.txt). Use it in your games, commercial too; do not resell the files.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
