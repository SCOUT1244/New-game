GRIDWRIGHT BOOK & JOURNAL UI - FREE SAMPLE  v1.0
================================================

A free taste of Gridwright Book & Journal UI: the Adventurer cover in both sizes (open, closed, the opening animation and the
page turn), 50 of the 259 paper-kit pieces and the envelope animation. The same files,
grid and layout as the full pack.

The full pack has 4 covers (Adventurer, Royal, Arcane, Ranger), each with open, close, page turn forward and
back plus the turning page and its shadow as separate layers, the whole paper kit (18 ink boxes and panels, 5 title ribbons, 8 dividers and ornaments, 11 buttons, 12 checkboxes, radios, toggles, slider, 6 progress bars, 6 scrollbar, 8 item slots, 22 page corners, arrows, close, 7 text field, dropdown, list rows, tooltip, 36 bookmark tabs, 6 hanging bookmarks, 32 icons, 10 stamps, 10 wax seals, 14 letters, notes, scroll pieces, photo corners, 23 map kit, 22 decorations, 3 cursors),
the scroll animation, four example spreads and the Story font.

Licence: the same as the full pack (LICENSE.txt): use it in your games, commercial ones too; don't resell the files.
Made by code. No third-party art.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
