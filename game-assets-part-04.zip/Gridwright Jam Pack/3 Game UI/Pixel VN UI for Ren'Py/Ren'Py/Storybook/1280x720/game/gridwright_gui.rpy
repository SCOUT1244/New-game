## Gridwright Pixel VN UI: Storybook theme, 1280x720.
##
## The extras that go with gui.rpy and the gui folder: crisp pixel text, the
## click-to-continue arrow, name plates in six colours, side images in the
## portrait socket and pixel-font titles. Nothing in screens.rpy is changed;
## the style statements below only add properties to Ren'Py's own styles.

init offset = -1

## Pixel art stays sharp when the window is scaled to another size. Set it to
## False if your game also uses smooth, painted art that should be filtered.
define config.nearest_neighbor = True

## The click-to-continue arrow after every line (4 frames).
image gw_ctc:
    "gui/ctc/ctc_1.png"
    0.14
    "gui/ctc/ctc_2.png"
    0.14
    "gui/ctc/ctc_3.png"
    0.14
    "gui/ctc/ctc_4.png"
    0.14
    repeat

## Every character gets the arrow: Character("Mia") uses these by default.
define adv = Character(None, kind=adv, ctc="gw_ctc", ctc_position="nestled")
define nvl = Character(None, kind=nvl, ctc="gw_ctc", ctc_position="nestled")

init -1 python:

    def gw_namebox(colour):
        """
        A name plate in one of the six colours of this theme (wood, crimson, navy, forest, plum, slate):

            define m = Character("Mia", **gw_namebox("crimson"))
        """
        return dict(namebox_background=Frame("gui/namebox/namebox_%s.png" % colour,
                                             gui.namebox_borders, tile=gui.namebox_tile, xalign=gui.name_xalign))

    def gw_side(picture):
        """
        Puts a 64x64 pixel portrait (or any picture, fitted) into the portrait
        socket of the side-image dialogue box (set gui.gw_side_images = True):

            image side mia = gw_side("mia_portrait.png")
            define m = Character("Mia", image="mia")
        """
        p = gui.gw_pixel
        return Fixed(
            Transform(picture, fit="contain", xysize=(64 * p, 64 * p), nearest=True, xpos=46 * p, ypos=0),
            xysize=(110 * p, 74 * p))

init offset = 1

## Pixel fonts: no smoothing, no hinting; the sizes in gui.rpy are whole
## multiples of each font's own pixel size.
style default:
    antialias False
    hinting "none"

style window:
    background Image(("gui/textbox_side.png" if gui.gw_side_images else "gui/textbox.png"), xalign=0.5, yalign=1.0)

style quick_menu:
    yoffset -6

style main_menu_title:
    outlines [ (0, gui.gw_title_shadow, gui.gw_pixel, gui.gw_pixel) ]

style main_menu_version:
    color gui.title_text_color
    outlines [ (0, gui.gw_title_shadow, gui.gw_pixel, gui.gw_pixel) ]

style game_menu_label_text:
    font gui.title_text_font
    size gui.gw_menu_title_size
    color gui.gw_menu_title_color
    outlines [ (0, gui.gw_menu_title_shadow, gui.gw_pixel, gui.gw_pixel) ]

## Names on the NVL page sit on the panel, not on a name plate.
style nvl_label:
    color gui.accent_color

style skip_text:
    font gui.gw_small_font
    color gui.gw_small_text_color

style skip_triangle:
    color gui.gw_small_text_color
