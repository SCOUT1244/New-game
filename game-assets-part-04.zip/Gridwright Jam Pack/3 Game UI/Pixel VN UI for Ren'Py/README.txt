GRIDWRIGHT PIXEL VN UI - FREE SAMPLE  v1.0
==========================================

The Storybook theme, complete, for a 1280x720 Ren'Py project. Copy everything inside
Ren'Py\Storybook\1280x720\game\ into your project's game\ folder (it replaces the gui\ images and gui.rpy)
and launch. Tested in Ren'Py 8.5.3.

The full pack has 4 themes (Storybook, Neon, Sakura, Gothic), each at 1920x1080 and 1280x720, the
side-image dialogue box, a demo project per theme, and every piece as PNG + 9-slice data for other engines.

Licence: use it in your games, free or paid; do not redistribute the files. Full text in LICENSE.txt.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
