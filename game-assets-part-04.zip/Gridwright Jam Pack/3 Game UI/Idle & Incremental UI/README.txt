GRIDWRIGHT IDLE & INCREMENTAL UI - FREE SAMPLE  v1.0
====================================================

A free taste of Gridwright Idle & Incremental UI: 68 sprites at 1x, 2x and 3x, with the same folders, names and JSON maps
as the full pack: currencies and boosts, two generators in all 3 tiers, the rare egg hatch, the epic chest opening,
slots, a card and the card back, the rare reveal beam, a panel, upgrade rows, the currency pill, buttons, buy toggles,
a bar, the gold coin spin, and the white Idle Numbers font (BMFont).

The full pack has 387 sprites: 46 currency icons, 37 boosts, 36 generator icons,
the rarity system in 7 tiers, 76 UI pieces and 42 effect frames, plus the gold font.

Licence: the same as the full pack (LICENSE.txt): use it in your games, commercial ones too; don't resell the files.
Made by code. No third-party art.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
