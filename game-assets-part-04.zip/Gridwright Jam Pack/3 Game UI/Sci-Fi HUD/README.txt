GRIDWRIGHT SCI-FI HUD - FREE SAMPLE  v1.0
=========================================

112 sprites: the cyan theme's core of the Gridwright Sci-Fi HUD (panels, buttons, slots, bars, reticles, the
lock-on, the whole radar sweep, an alert, a spinner, inputs), plus 12 icons (colour and white), 3 cursors,
blips, bar fills and the digits 0-9: enough for a working HUD.
Same grid, same file names and same licence as the full pack.

The full pack has 136 sprites per theme in 4 themes (cyan, green, amber, red)
and 125 shared sprites: 669 sprites in all.

FOLDERS
  PNG\1x\cyan\<category>\   every sprite as its own file (2x and 3x are the same, pre-scaled)
  PNG\1x\icons\, icons_white\, cursors\, map\, bar_fills\, digits\
  Sheets\                    a sprite sheet per set and scale, plus a JSON map

THE GRID
  At 1x every sprite is 32, 64 or 96 pixels wide and high. Use nearest-neighbour filtering.

9-SLICE
  Panels (96x96): margins 32 on all four sides. Wide buttons, bars, the alert (96x32): margins 32 left and right.
  The JSON gives the margins of every sprite: "slice": [left, top, right, bottom].

RADAR AND BARS
  Draw radar_frame, then radar_sweep_01..08 in order, then the blips. Draw bar_frame, then stretch bar_fill_*
  inside its "content" rectangle (tile the segmented fill).

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every sprite is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
