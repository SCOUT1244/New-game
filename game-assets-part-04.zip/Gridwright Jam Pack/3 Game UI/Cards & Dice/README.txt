GRIDWRIGHT CARDS & DICE - FREE SAMPLE  v1.0
===========================================

33 sprites from the Gridwright Cards & Dice (826 sprites):
the 13 classic spades, a joker, a card back, a blank card, a white d6 (1-6), four red d20 faces, chips, two suits and a cloth tile.
PNG at 1x, 2x and 3x plus a sprite sheet with a JSON map. everything_in_the_full_pack.png shows the whole pack.

The card art is 31x47 inside a 32x48 cell (dice: 15x15 in 16x16, 31x31 in 32x32), so pips and numbers have a true middle.
Scale by whole numbers and turn texture filtering off.

LICENCE (the full text is in LICENSE.txt)
  Use the sprites in personal and commercial games and apps, and change them as you like.
  Do not resell or redistribute them as assets. Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every sprite is drawn by code (Python).

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
