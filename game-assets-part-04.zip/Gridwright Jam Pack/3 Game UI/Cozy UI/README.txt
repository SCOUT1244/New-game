GRIDWRIGHT COZY UI - FREE SAMPLE  v1.0
======================================

The whole Cottage theme from Gridwright Cozy UI (40 pieces), 12 of its 50
icons and the 4 cursors, with the same files, sheets, 9-slice data and licence as the full pack
(3 themes, 174 sprites). made_with_the_full_pack.gif shows all the themes.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit is required: write "Art by Gridwright" with a link to https://gridwrightstudio.itch.io in your game's credits or on its store page. Not for AI training or NFTs.

HOW IT WAS MADE
  Every sprite is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
