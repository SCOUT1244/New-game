GRIDWRIGHT PIXEL UI KIT - FREE SAMPLE  v1.0
===========================================

62 sprites from the stone theme of the Gridwright Pixel UI Kit: enough to build a menu and a small HUD.
Same grid, same file names and same licence as the full kit.

The full kit has 245 sprites per theme in 6 themes (stone, wood, parchment, scifi, dark, pastel),
1534 sprites in all.

FOLDERS
  PNG\1x\stone\<category>\   every sprite as its own file (2x and 3x are the same, pre-scaled)
  Sheets\stone_1x.png         a sprite sheet per scale, plus a JSON map

THE GRID
  At 1x every sprite is 16, 32 or 48 pixels wide and high. Use nearest-neighbour filtering.

9-SLICE
  Panels (48x48): margins 16 on all four sides.
  Wide buttons, bars, inputs, sliders and dividers (48x16): margins 16 left and right.
  The JSON gives the margins of every sprite: "slice": [left, top, right, bottom].

BARS
  Draw bar_frame, then stretch bar_fill_* inside it: 2 px in from each end, rows 4 to 11.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every sprite is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
