GRIDWRIGHT CASUAL GAME UI - FREE SAMPLE  v1.0
=============================================

111 sprites: the candy theme's core of the Gridwright Casual Game UI (panels, a pop-up, a card, buttons in every state,
counter pills, bars, level nodes and path dots, slots, day cells, inputs, sparkles), plus 12 icons (colour and white),
2 cursors, 4 bar fills, 3 stars, 2 badges, the whole coin spin and star pop, and the digits 0-9:
enough for a working menu and level map.
Same grid, same file names and same licence as the full pack.

The full pack has 76 sprites per theme in 5 themes (candy, sky, lime, sun, grape)
and 140 shared sprites: 520 sprites in all.

FOLDERS
  PNG\1x\candy\<category>\   every sprite as its own file (2x and 3x are the same, pre-scaled)
  PNG\1x\icons\, icons_white\, cursors\, digits\, bar_fills\, stars\, badges\, anims\
  Sheets\                    a sprite sheet per set and scale, plus a JSON map

THE GRID
  At 1x every sprite is 32, 64, 96 or 128 pixels wide and high. Use nearest-neighbour filtering.

9-SLICE
  Panels (96x96) and the card (96x128): margins 32 on all four sides. Wide buttons, pills, bars (96x32): margins 32 left and right.
  The JSON gives the margins of every sprite: "slice": [left, top, right, bottom].

BUTTONS AND BARS
  Swap button_*_normal for button_*_pressed on press: the lip disappears and the face sinks 4 px.
  Draw bar_frame, then stretch bar_fill_* inside its "content" rectangle.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every sprite is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
