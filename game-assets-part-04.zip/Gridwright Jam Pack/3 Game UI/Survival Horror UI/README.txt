GRIDWRIGHT SURVIVAL HORROR UI - FREE SAMPLE  v1.0
=================================================

73 sprites from Gridwright Survival Horror UI: the Rust theme's core (panels, the inspection frame,
buttons, inventory and combine slots, the ECG monitor in Fine with its 4 frames, a bar frame, the battery in
5 levels, the ammo counter, a save slot, the name plate, the next arrow and a key cap), 10 items at 16x16,
32x32 and white, 3 bar fills, a torn note, the typewriter, the REC blink and viewfinder corners, GAME OVER and
2 cursors. Same grid, same file names and same licence as the full pack.

The full pack has 68 sprites per theme in 4 themes (rust, occult, clinic, vhs)
and 325 shared sprites: 597 sprites in all, with 60 items, the map kit and the whole camcorder HUD.

LICENCE: the same as the full pack (LICENSE.txt). Use it in your games, commercial too; do not resell the files.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
