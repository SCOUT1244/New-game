GRIDWRIGHT FANTASY RPG UI - FREE SAMPLE  v1.0
=============================================

78 sprites: the gold theme's core of the Gridwright Fantasy RPG UI, plus 12 icons (colour and white),
3 cursors, the compass, a map pin, a quest marker, 4 orb liquids and 3 bar fills: enough for a character sheet and a small HUD.
Same grid, same file names and same licence as the full pack.

The full pack has 98 sprites per theme in 4 themes (gold, silver, bronze, iron)
and 119 shared sprites: 511 sprites in all.

FOLDERS
  PNG\1x\gold\<category>\   every sprite as its own file (2x and 3x are the same, pre-scaled)
  PNG\1x\icons\, icons_white\, cursors\, map\, orb_liquids\, bar_fills\
  Sheets\                    a sprite sheet per set and scale, plus a JSON map

THE GRID
  At 1x every sprite is 32, 64 or 96 pixels wide and high. Use nearest-neighbour filtering.

9-SLICE
  Panels (96x96): margins 32 on all four sides. Wide buttons, bars, the scroll parts (96x32): margins 32 left and right.
  The JSON gives the margins of every sprite: "slice": [left, top, right, bottom].

ORBS AND BARS
  Draw orb_health_<level>, then orb_frame on top. Draw bar_frame, then stretch bar_fill_* inside its "content" rectangle.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every sprite is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
