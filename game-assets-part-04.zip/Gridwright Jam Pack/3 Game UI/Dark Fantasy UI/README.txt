GRIDWRIGHT DARK FANTASY UI - FREE SAMPLE  v1.0
==============================================

72 sprites: the Blood theme's core of the Gridwright Dark Fantasy UI (panels, buttons, tabs, bar frames,
the boss bar and name plate, the soul counter, slots, the quick-slot hub, inputs, dialogue pieces, a key prompt,
the lock-on reticle and 3 cursors), 10 icons in colour and white, 6 bar fills and the animated soul.
Same grid, same file names and same licence as the full pack.

The full pack has 94 sprites per theme in 4 themes (blood, bone, spectral, hallow)
and 104 shared sprites: 480 sprites in all.

FOLDERS
  PNG\1x\blood\<category>\   every sprite as its own file (2x and 3x are the same, pre-scaled)
  PNG\1x\icons\, icons_white\, bar_fills\, souls\
  Sheets\                    a sprite sheet per set and scale, plus a JSON map

THE GRID
  At 1x every sprite is 16, 32, 48 or 80 pixels wide and high. Use nearest-neighbour filtering.

9-SLICE AND BARS
  Panels (48x48): margins 16 on all four sides. Buttons, bars, name plates (48x16): margins 16 left and right.
  The JSON gives every sprite's margins ("slice") and inside area ("content").
  Draw a bar frame, then the fills at the frame's own x and y, stretched to content width x percent.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every sprite is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
