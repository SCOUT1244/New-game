GRIDWRIGHT TOP-DOWN CHARACTERS - FREE SAMPLE  v1.0
==================================================

56 sprites from the Gridwright Top-Down Characters: two complete characters (Villager, Adventurer,
24 frames each) and four emote bubbles. Same grid, sheet layout, file names and licence as the full pack
(16 characters, 409 sprites).

THE SHEET LAYOUT
  columns 1-2 idle, 3-6 walk; rows down, left, right, up. Idle about 3 fps, walk about 8 fps.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every frame is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
