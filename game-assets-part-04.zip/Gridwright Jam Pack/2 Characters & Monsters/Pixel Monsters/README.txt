GRIDWRIGHT PIXEL MONSTERS - FREE SAMPLE  v1.0
=============================================

83 sprites from the Gridwright Pixel Monsters: the slime and the bat in all 3 colours (move, hurt, death)
and the walking goblin (all 29 frames). Same grid, sheet layout, file names and licence as the full pack
(10 creatures in 3 colours, 4 walking monsters, 386 sprites).

ANIMATION
  move: loop 1-4 at 6-8 fps; hurt: about 0.1 s; death: 1-4 once at about 10 fps.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every frame is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
