GRIDWRIGHT PIXEL PNGTUBER AVATARS - FREE SAMPLE  v1.0
=====================================================

A free taste of Gridwright Pixel PNGTuber Avatars: 2 avatars (Neko, Bit Bot), each with all
8 expressions x 4 states (idle, blink, talk, talk_blink), at 64, 128, 256, 512 px, with
their sheets, bounce GIFs and avatars.json. The same files and layout as the full pack.

The full pack has 10 avatars: Neko, Cozy Dev, Pixel Witch, Bit Bot, Elf Mage, Little Demon, Space Alien, Rocker, Bunny, Gamer Knight.

How to use: one state per expression in your PNGTuber app; idle as the quiet picture, talk as the speaking
picture, blink and talk_blink as the blinking versions. See README of the full pack for more.
In the file names and JSON, the shocked expression is "surprised" and ouch is "hurt".

Licence: the same as the full pack (LICENSE.txt): use them on your streams and in your games, commercial ones too; don't resell
the files. Credit is required: "Art by Gridwright" with a link; on a stream or in a video, in your channel's panels or the video
description. Made by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
