GRIDWRIGHT PIXEL PORTRAITS - FREE SAMPLE  v1.0
==============================================

A free taste of Gridwright Pixel Portraits: 3 ready-made characters (Elf Archer, Captain, Office Worker),
each in 8 expressions x 4 frames (still, blink, talk 1, talk 2), and 25 of the 330
layers with Tools\compose.py. 64x64, at 1x, 2x and 3x, the same files and layout as the full pack.

Stack layers in this order: hair_back, body, outfit, eyes, beard, hair, brows, headwear, accessory.
Sheet layout: columns still, blink, talk 1, talk 2; rows neutral, happy, sad, angry, surprised, thinking,
scared, hurt.

The full pack has 36 ready-made characters (fantasy, sci-fi and modern) and 330 layers:
18 bodies, 9 eye sheets, 8 brow sheets, 104 hair fronts + 32 hair backs, 40 beards, 67 outfits, 37 headwear, 15 accessories.

Licence: the same as the full pack (LICENSE.txt): use it in your games, commercial ones too; don't resell the files.
Made by code. No third-party art.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
