GRIDWRIGHT MODERN PEOPLE - FREE SAMPLE  v1.0
============================================

A free taste of Gridwright Modern People: 2 ready-made characters (Office Worker, Student) and
12 of the 243 layer sheets, with Tools\compose.py and the same layout as the full pack:
4 directions x 10 frames (idle 2, walk 4, sit 2, phone 2), 16x16, at 1x, 2x and 3x.

Stack layers in this order: body, shoes, bottom, top, back, beard, hair, face, head.
Sheet layout: columns 1-2 idle, 3-6 walk, 7-8 sit, 9-10 phone; rows down, left, right, up.

The full pack has 20 ready-made characters and 243 layers: 5 skin tones,
8 hair styles x 8 colours, 8 tops x 12 colours,
3 bottoms, 2 kinds of shoes, beards and accessories.

Licence: the same as the full pack (LICENSE.txt): use it in your games, commercial ones too; don't resell the files.
Made by code. No third-party art.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
