"""Gridwright Modern People - stack layer sheets into one character sheet.

Usage (needs Python 3 and Pillow: pip install pillow):
    python compose.py my_character.png <layer sheet> <layer sheet> ...

Give the layer sheets of one scale (all 1x, all 2x or all 3x) in any order: they are stacked in the pack's slot
order (body, shoes, bottom, top, back, beard, hair, face, head), read from the file names. Files whose names the
script doesn't know are stacked in the order you gave them, after the known ones.
"""
import sys
from pathlib import Path

from PIL import Image

ORDER = ['body', 'shoes', 'bottom', 'top', 'back', 'beard', 'hair', 'face', 'head']
PREFIX = [('body_', 'body'), ('shoes_', 'shoes'), ('boots_', 'shoes'), ('pants_', 'bottom'), ('shorts_', 'bottom'),
          ('skirt_', 'bottom'), ('tshirt_', 'top'), ('tank_', 'top'), ('hoodie_', 'top'), ('sweater_', 'top'),
          ('shirt_tie_', 'top'), ('blazer_', 'top'), ('dress_', 'top'), ('coat_', 'top'), ('backpack_', 'back'),
          ('beard_', 'beard'), ('mustache_', 'beard'), ('hair_', 'hair'), ('glasses', 'face'),
          ('sunglasses', 'face'), ('cap_', 'head'), ('beanie_', 'head'), ('hardhat_', 'head'),
          ('headphones_', 'head')]


def slot_of(path):
    name = Path(path).stem
    for p, slot in PREFIX:
        if name.startswith(p):
            return ORDER.index(slot)
    return len(ORDER)


def main(argv):
    if len(argv) < 3:
        print(__doc__)
        return 1
    out, files = argv[1], argv[2:]
    files = sorted(files, key=lambda f: (slot_of(f), files.index(f)))
    base = None
    for f in files:
        img = Image.open(f).convert('RGBA')
        if base is None:
            base = Image.new('RGBA', img.size, (0, 0, 0, 0))
        if img.size != base.size:
            print(f'{f}: size {img.size} differs from {base.size}; use sheets of one scale')
            return 1
        base.alpha_composite(img)
    base.save(out)
    print(f'saved {out} from {len(files)} layers')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
