GRIDWRIGHT SIDE-VIEW CHARACTERS - FREE SAMPLE  v1.0
===================================================

149 sprites from the Gridwright Side-View Characters: two complete characters (Knight, Skeleton;
all 8 animations, facing right and left, 68 frames each), the hit spark and the dust effects.
Same frame size, sheet layout, JSON, file names and licence as the full pack (10 characters,
707 sprites).

THE SHEET LAYOUT
  6 x 16 frames of 32x32. Rows 1-8 face right: idle, walk, run, jump, fall, attack, hurt, death; rows 9-16 face left.
  Pivot bottom-centre (16, 32). Speeds and attack data are in each character's JSON.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every frame is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
