GRIDWRIGHT VIRTUAL PET KIT - FREE SAMPLE  v1.0
==============================================

A free taste of Gridwright Virtual Pet Kit: 273 images at 1x, 2x and 3x, with the same folders, names, strips and
pets.json as the full pack: two whole species (Mochi and Sprout) in all 4 stages with every animation (egg wobble and
hatch, idle, happy, eat, sleep, play, sick, sad, walk (right and left)), six care items at 32 and 16 px, the heart, Zzz and poop effects, a panel, stat bars, the heart
meter, buttons, the feed button, two mood bubbles, the pink device and the bedroom.

The full pack has 8 species, 928 pet frames, 29 care items at two sizes, 40 effect frames,
65 UI pieces, 4 device colours and 3 rooms.

Licence: the same as the full pack (LICENSE.txt): use it in your games, commercial ones too; don't resell the files.
Made by code. No third-party art.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
