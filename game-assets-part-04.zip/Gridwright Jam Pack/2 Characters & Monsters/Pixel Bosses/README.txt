GRIDWRIGHT PIXEL BOSSES - FREE SAMPLE  v1.0
===========================================

One boss from Gridwright Pixel Bosses: the Slime King, complete. All 7 animations (51 frames), both phases
(normal and enraged), facing right and left, its projectile and impact, with the same sheets, JSON and licence as
the full pack (8 bosses, 816 frames). made_with_the_full_pack.gif shows the full pack in a fight.

THE SHEETS
  Sheets\1x\<boss>_<phase>_<facing>.png: 7 rows (idle, move, attack, special, roar, hurt, death) of 96x96 cells,
  and a JSON with every frame's rectangle, fps, loop, the anchor (48, 96 = the ground under the boss), the attack's
  hit frames and hit box, and the special move's spawn frame and point. Every frame is also its own PNG in PNG\.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every frame is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
