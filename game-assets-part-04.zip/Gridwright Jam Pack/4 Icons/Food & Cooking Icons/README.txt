GRIDWRIGHT FOOD & COOKING ICONS - FREE SAMPLE  v1.0
===================================================

A free taste of Gridwright Food & Cooking Icons: 55 sprites at 1x, 2x and 3x, with the same folders, names and JSON maps
as the full pack: about 30 food, drink and cookware icons, steak and fish raw, cooked and burnt, two spoiled foods,
the boiling pot animation (4 frames), slots, the recipe arrow, plus and equals, the cooking timer ring, a star and a badge.

The full pack has 224 icons in 10 groups, 20 spoiled versions, 6 animations
and 21 UI pieces: 289 sprites.

Licence: the same as the full pack (LICENSE.txt): use it in your games, commercial ones too; don't resell the files.
Made by code. No third-party art.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
