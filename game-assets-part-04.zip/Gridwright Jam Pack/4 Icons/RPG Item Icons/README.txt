GRIDWRIGHT RPG ITEM ICONS - FREE SAMPLE  v1.0
=============================================

44 icons from the Gridwright RPG Item Icons: a taste of every category.
Same size (16x16), same file names and same licence as the full pack.
The full pack has 507 icons. Preview\ shows all of them.

FOLDERS
  PNG\1x\<category>\      every icon as its own file (2x, 3x, 4x are the same, pre-scaled)
  Sheets\sample_1x.png     the sample on one sheet, plus a JSON map

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every icon is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
