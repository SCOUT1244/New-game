GRIDWRIGHT ANIMALS & PETS - FREE SAMPLE  v1.0
=============================================

3 animals from Gridwright Animals & Pets with every frame: Cat (orange tabby), Dog (golden), Sparrow
(216 frames), and the 2 shadow sprites. Same grid, sheet layout, file names and licence as the full
pack (32 animals, 2304 frames). made_with_the_full_pack.gif shows the full pack in a scene.

THE SHEETS
  Sheets\1x\<animal>.png: 18 columns x 4 rows (down, left, right, up), and a JSON with every frame's rectangle.
  Four-legged: idle 1-2, walk 1-4, run 1-4, eat 1-2, sleep 1-2, attack 1-2, hurt 1, dead 1.
  Birds: idle 1-2, hop 1-4, peck 1-2, takeoff 1-2, fly 1-4, land 1-2, hurt 1, dead 1.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every frame is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
