GRIDWRIGHT FARM RPG - FREE VERSION  v1.9
========================================

THE FREE VERSION of Gridwright Farm RPG: the Farmer and the Farm Girl with every animation, the layers they are made of and the Farmer Generator with those layers, the spring crops, dry and watered soil, an apple tree, a few props, a chicken, a cow, a dog and a saddled horse to ride, and spring icons.
The full pack has 27 characters, 210 creator layers, 10 tools, the whole farm in four seasons, 26 animals and 100+ icons:
  https://gridwrightstudio.itch.io/farm-rpg-asset-pack-16x16-pixel-art-all-in-one

WHAT'S INSIDE
  characters     2 ready characters x 30 animations x 4 directions (440 frames each)
  creator       11 layer sheets: 2 body, 2 shoes, 2 tops, 2 overalls and aprons, 2 hair, 1 hats
              + 10 tools (each drawn in front of or behind the character, frame by frame) and the effects
  world        167 sprites: soil dry 47, soil wet 47, grass 4, fence 18, crops 42, trees 3, props 6
  animals        3 animals (3 species), 4 directions, 240 frames in all
  icons         24 icons (16x16): produce, seeds, fruit, goods, tools, fish and fishing gear
  engines           Godot 4 (SpriteFrames, a TileSet with terrains, a demo scene), Tiled (tilesets with wang sets,
                    a demo map), RPG Maker MV/MZ (characters, A2 and B-E tilesets)

THE ANIMATIONS (frames per direction)
  moves      idle 4, walk 4, run 4
  farm work  hoe 5, water 4, axe 5, pickaxe 5, sickle 4, shovel 5, saw 4, pickup 4, carry_idle 2, carry_walk 4, carry_run 4, throw 4
  fishing    fish_cast 5, fish_wait 2, fish_hooked 2, fish_reel 4, fish_caught 3
  combat     sword 4, bow 4, hurt 2, die 4
  rest       sit 2, sleep 2, pet 4
  riding     ride_idle 2, ride_walk 4, ride_run 4
  Rows are always in the same order: down, left, right, up. Down, right and up are drawn; left is right mirrored
  (its own row, nothing to flip in your engine).

FOLDERS
  Characters\Premades\<k>x\<name>\<name>_<group>.png      a sheet per animation group (moves, tools, fishing,
                                                         combat, rest, riding), tools and effects drawn in
  Characters\Premades\<k>x\<name>\animations\<anim>.png   one file per animation (4 rows x its frames)
  Characters\Layers\<k>x\<folder>\<layer>\<layer>_<group>.png   the creator's layers, the same layout
  Characters\Layers\<k>x\10 tools\<tool>\<tool>_<behind|front>_<group>.png   tools, split by depth
  Characters\Layers\<k>x\11 effects\effects_<group>.png    dirt, water, chips, sparks, slashes, line, stars
  Characters\JSON\sheet_<group>_<k>x.json                Aseprite JSON: frame rectangles, frame tags
                                                         (<anim>_<direction>), durations and every frame's anchors
  Characters\characters.json   animations, fps, loops, hit frames, the stack order, the premades' recipes, anchors
  Characters\Farmer Generator.html   open it in any browser: mix layers, preview, export sheets + JSON
  Characters\compose.py        stack layer sheets into one sheet from the command line (Python 3 + Pillow);
                               --ride puts a character on a saddled horse
  Characters\Riding\<k>x\     every character already on the saddled horses; riding.json: where the rider goes
  World\<k>x\...  Icons\<k>x\...  Animals\<k>x\...   single PNGs; World\Sheets and Icons\Sheets: sheets
  catalog.json                 every sprite: file, category, size, season, stage, bitmask
  Engines\Godot  Engines\Tiled  Engines\RPG Maker MV-MZ      see below
  Guide\                       pictures of the sheet layout, the anchors and the catalog
  <k>x = 1x, 2x, 3x (16, 32 and 48 px tiles). Use nearest-neighbour ("point") filtering and whole-number scales.

THE CELL AND THE ANCHORS
  Every character frame is 32x32 at 1x. The character stands on the bottom-centre 16x16 tile of the cell (the tile
  spans x 8-23, y 11-26); its feet are on row 25 and the pivot is (16, 27). Room above the head is for a raised axe,
  room in front of the feet for a hoe striking the ground.
  Every frame's anchors (in characters.json and each sheet JSON): hand_r (the hand that holds the tool), hand_l,
  tool, angle (degrees, 0 = pointing right, 90 = down), length (1 = full length; shorter when it points at the
  viewer), front (true = drawn in front of the body), tip (the tool's far end: where the soil turns or the tree is
  hit), item (where a carried crate, a crop or the caught fish sits: its centre-bottom).
  Hit frames (the frame where the work happens): hoe 3, axe 3, pickaxe 3, sickle 3, shovel 2, sword 3, bow 4, throw 3, water 3, fish_cast 4 (1-based).
  Tools are separate sprites on purpose: hide them, swap them for your own (copper, gold...) at the anchor, or use
  the drawn ones. A buyer's tool goes behind the character when front is false.

THE CREATOR
  Hair: 14 styles in 7 colours (short, long, ponytail, spiky, bob, bun, curly, buzz, braid, pigtails, mohawk, afro, side part, long wavy). The mohawk
  and the afro rise above the head; they stay inside the 32x32 cell, so nothing moves.
  Stack, bottom to top: tool "behind" sheet, body, shoes, bottoms, top, overalls or apron, beard, hair, glasses, hat,
  tool "front" sheet, effects. Every layer fits every pose of every animation, because all of them paint the same
  body regions. The premades are recipes of these layers (characters.json lists them), so any of them can be
  re-dressed. The same rig as Gridwright Modern People and Gridwright Cozy Villagers: characters from all three
  packs mix in one game.

THE FARM
  Soil (dry and watered) and the path are 47-tile autotiles. NNN in the file name is the neighbour bitmask: add up
  the neighbours that are also soil (or also path):
        NW=128   N=1    NE=2
        W=64     tile   E=4
        SW=32    S=16   SE=8
  A diagonal neighbour only counts when the two neighbours next to it are set. Count dry AND watered soil as tilled
  when you work out the bitmask, then pick soil_dry_NNN or soil_wet_NNN per tile: they join without a seam.
  Grass: 4 tiles per season (spring, summer, autumn, winter) that mix freely.
  Crops: 16x32 frames, the plant on the bottom 16x16 cell; stages seeds, sprout, young, growing, ripe, withered.
  Sorted by season in World\<k>x\Crops\<season>\. Fruit trees (32x48) in spring (blossom), summer (fruit) and
  autumn; tree_fruit_winter is every fruit tree in winter. Oak in four seasons, pine and a snowy pine.
  Fences: fence_JJ, JJ = the neighbours that are fence (1 north, 2 east, 4 south, 8 west).

THE DOG CAN SIT AND BE PETTED (Update 2)
  Animals\<k>x\dog_golden.png has 6 columns on the right, after its usual 18: sit 1-2 (3 frames per second, a loop) and
  petted 1-4 (6 frames per second, a loop: eyes shut, the head dips, the tail wags). petted has the same length and speed
  as the farmer's pet animation, so start them together. catalog.json lists the columns. The full pack has 6 dogs and 6 cats.

ON HORSEBACK (Update 7)
  Every character has 3 riding animations (ride_idle 2, ride_walk 4, ride_run 4 frames) in its "riding" sheet, in
  every creator layer too, frame for frame with the horse's idle, walk and run and at the same speeds (3, 8 and 12
  frames a second).
  Animals\<k>x\horse_bay_saddled.png: the horse with its saddle, 10 columns (idle 1-2,
  walk 1-4, run 1-4) x 4 rows (down, left, right, up) of 32x32. The same horse as its own sheet, in the same place in
  the cell, so it can stand saddled and be mounted. ..._saddled_front.png: its head and neck alone (only the down row
  has them).
  A rider, per frame: draw the saddled horse, then the rider's ride_<gait> frame (the same frame number) with its
  32x32 cell's top-left at the "rider" offset of Characters\riding.json from the horse cell's top-left, then the
  front sheet on top: facing down the horse's head and neck are in front of the rider. Left is right mirrored, offsets
  included. Every offset keeps the rider's hips on the saddle; the run lifts the rider out of it on 2 frames.
  Characters\Riding\<k>x\<character>_on_<horse>.png: all 2 characters already on the horse, 32x40 cells
  (the horse 8 px down, the pivot (16, 39)), the same columns and rows.
  Your own character: stack its *_riding.png layers with compose.py, then
    python compose.py --ride my_rider_on_bay.png my_rider_riding.png ../Animals/1x/horse_bay_saddled.png
  Godot: gridwright_farmrpg\riding\riding.tscn plays a horse and a rider together (ride("walk", "right")); the demo
  has one walking along the path.

ENGINES
  Godot 4: open Engines\Godot as a project (Godot 4.3 or newer). gridwright_farmrpg\characters\<name>\<name>.tres
  are SpriteFrames (animations <anim>_<direction>); farm_tileset.tres has terrains for soil, watered soil and the path
  (paint them with the terrain tool), grass, crops and fences.
  demo.tscn: arrow keys walk, Space works the hoe.
  gridwright_farmrpg\riding\: the saddled horses as SpriteFrames and riding.tscn, a horse and a rider played together.
  Tiled: Engines\Tiled\*.tsx (soil, watered soil and the path with wang sets for the terrain brush), farm_demo.tmx.
  RPG Maker MV/MZ: copy Engines\RPG Maker MV-MZ\img\ into your project. Characters are $farmrpg_<name>.png
  (one character per file: step, stand, step x down, left, right, up). FarmRPG_A2.png: ground autotiles (soil, watered
  soil, path, grass); FarmRPG_B-E.png: crops, trees, props and buildings, fences and debris.
  Set them in Database > Tilesets. RPG Maker uses 48 px tiles: these are the 3x art.

WHAT COMES FROM OUR OTHER PACKS
  So the Gridwright packs match, this one shares sprites with three of them: the soil, path, fences, the 20 crops,
  produce, seed packets, props, buildings, debris and goods are the ones in Gridwright Farm (here sorted by season);
  the horse, the dog and cat bodies and 8 of their coats are from Gridwright Animals & Pets; the fish and fishing gear
  icons from Gridwright Fish & Fishing; the clothes, hair and hats are drawn on the rig of Gridwright Modern People and
  Cozy Villagers.
  New in this pack: the working farmer with its 30 animations, the creator and the Farmer Generator, the premades,
  the tools, the cow, pig, sheep, goat, chicken and duck in four directions, the husky, shepherd, corgi, dalmatian and
  siamese, sitting and being petted, the seasons, the fruit and forest trees, the fruit icons, the water, the mayor's
  office, the waistcoat, shop apron, sash and flat cap, the garlic, rice, coffee, hops, grapes and cotton, the watered
  look of every crop, the farmhouse floors, walls, kitchen, bedroom and living room, the saddle and the riders, the
  braid, pigtails, mohawk, afro, side part and long wavy hair, the soil soaking in, the sprinklers, the can's splash,
  the puddles, and the engine files.

CREDIT
  Credit is required: write "Art by Gridwright" with a link to https://gridwrightstudio.itch.io in your game's credits or on its store page.

UPDATES
  This pack grows: new content arrives as free updates for everyone who has it. CHANGELOG.txt lists them.
  Ask for what you need in our Discord (the link is below).

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
