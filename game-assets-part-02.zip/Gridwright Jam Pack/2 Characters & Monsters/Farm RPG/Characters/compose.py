"""Gridwright Farm RPG - stack the layer sheets of the farmer creator into one character sheet.

Usage (needs Python 3 and Pillow: pip install pillow):
    python compose.py my_farmer.png <layer sheet> <layer sheet> ...

Give sheets of one animation group and one scale (for example all *_tools.png at 1x). They are stacked in the
creator's slot order, read from the folder names: tool "behind" sheets, body, shoes, bottoms, tops, overalls and
aprons, beards, hair, glasses, hats, tool "front" sheets, effects. Unknown files go on top, in the order you gave.

Example (a farmer with a hoe, the tools group, 1x):
    python compose.py farmer_tools.png Layers/1x/10\ tools/hoe/hoe_behind_tools.png \
        "Layers/1x/1 body/body_tan/body_tan_tools.png" "Layers/1x/2 shoes/boots_brown/boots_brown_tools.png" \
        "Layers/1x/4 tops/tshirt_red/tshirt_red_tools.png" "Layers/1x/7 hair/hair_short_brown/hair_short_brown_tools.png" \
        "Layers/1x/9 hats/straw_hat_straw/straw_hat_straw_tools.png" Layers/1x/10\ tools/hoe/hoe_front_tools.png \
        "Layers/1x/11 effects/effects_tools.png"

On horseback (Update 7): first stack your character's "riding" sheets as above, then put it on a horse:
    python compose.py --ride my_rider_on_bay.png my_farmer_riding.png ../Animals/1x/horse_bay_saddled.png

The result has the layout of Characters/Riding/: 10 columns (idle 1-2, walk 1-4, run 1-4) x 4 rows (down, left, right,
up) of 32x40 cells, the horse 8 px down, the rider on its saddle by riding.json, the horse's head over the rider facing
down. Any scale works: give the rider and the horse sheets of the same scale (1x, 2x or 3x).
"""
import json
import sys
from pathlib import Path

from PIL import Image


def ride(out, rider_path, horse_path):
    """Bake a rider's riding sheet onto a saddled horse (riding.json beside this file)."""
    spec = json.loads((Path(__file__).resolve().parent / 'riding.json').read_text(encoding='utf-8'))
    horse = Image.open(horse_path).convert('RGBA')
    front_path = Path(horse_path).with_name(Path(horse_path).stem + '_front.png')
    front = Image.open(front_path).convert('RGBA')
    rider = Image.open(rider_path).convert('RGBA')
    cols, rows = spec['columns'], spec['rows']
    k = horse.width // (len(cols) * spec['horse_cell'])
    c = spec['horse_cell'] * k
    w, h = spec['baked']['cell'][0] * k, spec['baked']['cell'][1] * k
    top = spec['baked']['horse_at'][1] * k
    anims = list(dict.fromkeys(spec['rider_animation'].values()))
    if rider.width < 4 * c or rider.height != len(anims) * len(rows) * c:
        print(f'{rider_path}: not a riding sheet at {k}x ({rider.size}); stack the *_riding.png sheets of one scale')
        return 1
    sheet = Image.new('RGBA', (len(cols) * w, len(rows) * h), (0, 0, 0, 0))
    for r, d in enumerate(rows):
        for ci, col in enumerate(cols):
            gait, i = col.rsplit('_', 1)
            i = int(i) - 1
            ox, oy = spec['frames'][f'{d}/{col}']['rider']
            ra = anims.index(spec['rider_animation'][gait]) * len(rows) + r
            cell = Image.new('RGBA', (w, h), (0, 0, 0, 0))
            for img, x, y, (sx, sy) in ((horse, 0, top, (ci * c, r * c)),
                                        (rider, ox * k, top + oy * k, (i * c, ra * c)),
                                        (front, 0, top, (ci * c, r * c))):
                part = img.crop((sx, sy, sx + c, sy + c))
                cell.paste(part, (x, y), part)
            sheet.paste(cell, (ci * w, r * h))
    sheet.save(out)
    print(f'saved {out}: {rider_path} on {horse_path}')
    return 0

ORDER = ['behind', '1 body', '2 shoes', '3 bottoms', '4 tops', '5 overalls and aprons', '6 beards', '7 hair', '8 face',
         '9 hats', 'front', '11 effects']


def slot_of(path):
    p = Path(path)
    name = p.stem
    if '_behind_' in name:
        return 0
    if '_front_' in name:
        return ORDER.index('front')
    for part in p.parts:
        if part in ORDER:
            return ORDER.index(part)
    return len(ORDER)


def main(argv):
    if len(argv) == 5 and argv[1] == '--ride':
        return ride(argv[2], argv[3], argv[4])
    if len(argv) < 3:
        print(__doc__)
        return 1
    out, files = argv[1], argv[2:]
    files = sorted(files, key=lambda f: (slot_of(f), files.index(f)))
    base = None
    for f in files:
        img = Image.open(f).convert('RGBA')
        if base is None:
            base = Image.new('RGBA', img.size, (0, 0, 0, 0))
        if img.size != base.size:
            print(f'{f}: size {img.size} differs from {base.size}; use sheets of one group and one scale')
            return 1
        base = Image.alpha_composite(base, img)
    base.save(out)
    print(f'saved {out} from {len(files)} layers')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
