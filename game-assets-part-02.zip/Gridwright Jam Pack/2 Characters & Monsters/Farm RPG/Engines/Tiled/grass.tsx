<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="grass" tilewidth="16" tileheight="16" tilecount="8" columns="8">
 <image source="grass.png" width="128" height="16"/>
 <tile id="0"><properties><property name="name" value="grass_spring_1"/></properties></tile>
 <tile id="1"><properties><property name="name" value="grass_spring_2"/></properties></tile>
 <tile id="2"><properties><property name="name" value="grass_spring_3"/></properties></tile>
 <tile id="3"><properties><property name="name" value="grass_spring_4"/></properties></tile>
</tileset>
