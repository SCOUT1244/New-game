<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="fence" tilewidth="16" tileheight="16" tilecount="24" columns="8">
 <image source="fence.png" width="128" height="48"/>
 <tile id="0"><properties><property name="name" value="fence_00"/></properties></tile>
 <tile id="1"><properties><property name="name" value="fence_01"/></properties></tile>
 <tile id="2"><properties><property name="name" value="fence_02"/></properties></tile>
 <tile id="3"><properties><property name="name" value="fence_03"/></properties></tile>
 <tile id="4"><properties><property name="name" value="fence_04"/></properties></tile>
 <tile id="5"><properties><property name="name" value="fence_05"/></properties></tile>
 <tile id="6"><properties><property name="name" value="fence_06"/></properties></tile>
 <tile id="7"><properties><property name="name" value="fence_07"/></properties></tile>
 <tile id="8"><properties><property name="name" value="fence_08"/></properties></tile>
 <tile id="9"><properties><property name="name" value="fence_09"/></properties></tile>
 <tile id="10"><properties><property name="name" value="fence_10"/></properties></tile>
 <tile id="11"><properties><property name="name" value="fence_11"/></properties></tile>
 <tile id="12"><properties><property name="name" value="fence_12"/></properties></tile>
 <tile id="13"><properties><property name="name" value="fence_13"/></properties></tile>
 <tile id="14"><properties><property name="name" value="fence_14"/></properties></tile>
 <tile id="15"><properties><property name="name" value="fence_15"/></properties></tile>
 <tile id="16"><properties><property name="name" value="gate_closed"/></properties></tile>
 <tile id="17"><properties><property name="name" value="gate_open"/></properties></tile>
</tileset>
