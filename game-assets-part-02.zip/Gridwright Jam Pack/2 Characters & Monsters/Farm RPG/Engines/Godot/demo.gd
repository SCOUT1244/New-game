extends Node2D
# Gridwright Farm RPG demo: grass, a field of tilled soil (half of it watered) painted with the TileSet's terrains,
# and the farmer. Arrow keys walk; Space works the hoe (or fishes, facing the pond, when the set has water).

@onready var ground: TileMapLayer = $Ground
@onready var soil: TileMapLayer = $Soil
@onready var farmer: AnimatedSprite2D = $Farmer
var facing := "down"

func _ready() -> void:
	for x in range(0, 40):
		for y in range(0, 23):
			ground.set_cell(Vector2i(x, y), 2, Vector2i(0 + (x * 7 + y * 3) % 4, 0))
	var dry: Array[Vector2i] = []
	var wet: Array[Vector2i] = []
	for x in range(6, 16):
		for y in range(5, 12):
			(wet if x >= 11 else dry).append(Vector2i(x, y))
	soil.set_cells_terrain_connect(dry, 0, 0)
	soil.set_cells_terrain_connect(wet, 0, 1)
	farmer.play("hoe_down")

func _process(delta: float) -> void:
	var v := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	if v != Vector2.ZERO:
		facing = "right" if v.x > 0.5 else "left" if v.x < -0.5 else "down" if v.y > 0 else "up"
		farmer.position += v * 48.0 * delta
		farmer.play("walk_" + facing)
	elif Input.is_action_pressed("ui_accept"):
		farmer.play("hoe_" + facing)
	elif not farmer.animation.begins_with("hoe") and not farmer.animation.begins_with("fish"):
		farmer.play("idle_" + facing)
