extends Node2D
## Gridwright Farm RPG: a rider on a saddled horse. Plays the horse, puts the rider on the saddle on every frame (the
## offsets of Characters/riding.json, baked in below) and draws the horse's head and neck over the rider facing down.
## Call ride("walk", "right"). Gaits: idle, walk, run. Directions: down, left, right, up. The node's position is the
## top-left of the horse's 32x32 cell; its feet stand on row 30. Give Rider any character's SpriteFrames from
## characters/ (they all have ride_idle, ride_walk and ride_run), and Horse / HorseFront a horse from this folder.

@export var gait := "idle"
@export var facing := "down"
@export var wander := false   # walks right and left along the demo's path by itself

@onready var horse: AnimatedSprite2D = $Horse
@onready var rider: AnimatedSprite2D = $Rider
@onready var front: AnimatedSprite2D = $HorseFront

const OFFSETS := {
	"idle_down": [Vector2i(0, -13), Vector2i(0, -14)],
	"idle_left": [Vector2i(3, -12), Vector2i(3, -13)],
	"idle_right": [Vector2i(-3, -12), Vector2i(-3, -13)],
	"idle_up": [Vector2i(0, -10), Vector2i(0, -10)],
	"walk_down": [Vector2i(0, -14), Vector2i(0, -15), Vector2i(0, -14), Vector2i(0, -15)],
	"walk_left": [Vector2i(3, -12), Vector2i(3, -13), Vector2i(3, -12), Vector2i(3, -13)],
	"walk_right": [Vector2i(-3, -12), Vector2i(-3, -13), Vector2i(-3, -12), Vector2i(-3, -13)],
	"walk_up": [Vector2i(0, -11), Vector2i(0, -12), Vector2i(0, -11), Vector2i(0, -12)],
	"run_down": [Vector2i(0, -12), Vector2i(0, -14), Vector2i(0, -13), Vector2i(0, -13)],
	"run_left": [Vector2i(3, -11), Vector2i(3, -13), Vector2i(2, -13), Vector2i(3, -12)],
	"run_right": [Vector2i(-3, -11), Vector2i(-3, -13), Vector2i(-2, -13), Vector2i(-3, -12)],
	"run_up": [Vector2i(0, -10), Vector2i(0, -12), Vector2i(0, -12), Vector2i(0, -11)],
}

func _ready() -> void:
	ride(gait, facing)

func ride(g: String, f: String) -> void:
	gait = g
	facing = f
	horse.play(g + "_" + f)
	_sync()

func _process(delta: float) -> void:
	if wander:
		position.x += (1.0 if facing == "right" else -1.0) * 30.0 * delta
		if position.x > 560.0 and facing == "right":
			ride("walk", "left")
		elif position.x < 40.0 and facing == "left":
			ride("walk", "right")
	_sync()

func _sync() -> void:
	var key := gait + "_" + facing
	var i := horse.frame
	rider.animation = "ride_" + key
	rider.frame = i
	front.animation = key
	front.frame = i
	rider.position = Vector2(OFFSETS[key][i])
