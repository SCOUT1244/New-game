GRIDWRIGHT FISH & FISHING - FREE SAMPLE  v1.0
=============================================

A free taste of Gridwright Fish & Fishing: 12 fish and creatures (rainbow trout, largemouth bass, common carp, koi,
clownfish, goldfish, bluefin tuna, anglerfish, blue crab, octopus, axolotl, golden carp) at 16x16 and 32x32 with their
icons, swim loops (both facings), silhouettes and swim strips; a wooden rod, the classic bobber with its idle, nibble and
bite animations in water, a lure, bait, an old boot, a treasure chest and a starfish; the cast splash and bite alert;
medium fish shadows; the catch bar, zone and marker and three rarity slots. fish.json has their names and game data.

The full pack has 130 fish and creatures, 47 items, 6 bobbers, 6 effects, 3 shadow sizes and the whole
fishing UI (2952 sprites). Same licence as the full pack (LICENSE.txt).

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
