GRIDWRIGHT HORROR MONSTERS - FREE SAMPLE  v1.0
==============================================

One monster from Gridwright Horror Monsters: the Rotting Zombie, complete. All 6 animations (30 frames), both
palettes (normal and cursed), facing right and left, with the same sheets, JSON and licence as the full pack
(10 monsters, 600 frames). made_with_the_full_pack.gif shows the full pack.

THE SHEETS
  Sheets\1x\<monster>_<palette>_<facing>.png: 6 rows (idle, walk, attack, hurt, death, spawn) of 48x48 cells, and
  a JSON with every frame's rectangle, fps, loop, the anchor (20, 48 facing right = the ground under the monster), the attack's
  hit frames and hit box. Every frame is also its own PNG in PNG\.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit is required: write "Art by Gridwright" with a link to https://gridwrightstudio.itch.io in your game's credits or on its store page. Not for AI training or NFTs.

HOW IT WAS MADE
  Every frame is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
