"""Gridwright Pixel Portraits - stack layers into one portrait sheet.

Usage (needs Python 3 and Pillow: pip install pillow):
    python compose.py my_portrait.png <layer> <layer> ...

Give layers of one scale (all 1x, all 2x or all 3x) in any order. They are stacked in the pack's slot order
(hair back, body, outfit, eyes, beard, hair, brows, headwear, accessory), read from the file names.

Two kinds of layer:
  - animated sheets (eyes_*, brows_*): 4 columns (still, blink, talk 1, talk 2) x 8 rows (expressions);
  - static images (everything else): one 64x64 portrait cell (128x128 at 2x, 192x192 at 3x).
If any sheet is given, the result is a full sheet and every static layer is repeated in every cell.
If only static layers are given, the result is one cell.
"""
import sys
from pathlib import Path

from PIL import Image

ORDER = ['hairback', 'body', 'outfit', 'eyes', 'beard', 'hair', 'brows', 'head', 'acc']
COLS, ROWS = 4, 8


def slot_of(path):
    name = Path(path).stem
    for i, slot in enumerate(ORDER):
        if name.startswith(slot + '_'):
            return i
    return len(ORDER)


def main(argv):
    if len(argv) < 3:
        print(__doc__)
        return 1
    out, files = argv[1], argv[2:]
    files = sorted(files, key=lambda f: (slot_of(f), files.index(f)))
    imgs = [(f, Image.open(f).convert('RGBA')) for f in files]
    cell = min(min(im.size) for _, im in imgs)
    sheet = any(im.size == (cell * COLS, cell * ROWS) for _, im in imgs)
    size = (cell * COLS, cell * ROWS) if sheet else (cell, cell)
    base = Image.new('RGBA', size, (0, 0, 0, 0))
    for f, im in imgs:
        if im.size == size:
            base.alpha_composite(im)
        elif im.size == (cell, cell):
            for j in range(size[1] // cell):
                for i in range(size[0] // cell):
                    base.alpha_composite(im, (i * cell, j * cell))
        else:
            print(f'{f}: size {im.size} fits neither a {cell}x{cell} cell nor a {COLS}x{ROWS} sheet; '
                  f'use layers of one scale')
            return 1
    base.save(out)
    print(f'saved {out} ({size[0]}x{size[1]}) from {len(files)} layers')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
