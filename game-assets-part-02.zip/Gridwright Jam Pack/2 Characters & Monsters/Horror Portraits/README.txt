GRIDWRIGHT HORROR PORTRAITS - FREE SAMPLE  v1.0
===============================================

A free taste of Gridwright Horror Portraits: 3 ready-made characters (Detective, Student, Vampire),
each in 8 expressions x 4 frames (still, blink, talk 1, talk 2), 23 of the 260
layers with Tools\compose.py, the 4 frames and their Ren'Py side images. 64x64, at 1x, 2x and 3x, the same
files and layout as the full pack.

Stack layers in this order: hair_back, body, outfit, eyes, beard, hair, brows, headwear, accessory.
Sheet layout: columns still, blink, talk 1, talk 2; rows neutral, scared, terrified, crying, angry, creepy smile,
possessed, hurt.

The full pack has 30 ready-made characters (survivors, antagonists, and three survivors as infected
and turned) and 260 layers: 24 bodies, 11 eye sheets, 6 brow sheets, 78 hair fronts + 24 hair backs, 30 beards, 46 outfits, 24 headwear, 17 face and neck pieces.

Licence: the same as the full pack (LICENSE.txt): use it in your games, commercial ones too; don't resell the files.
Made by code. No third-party art.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
