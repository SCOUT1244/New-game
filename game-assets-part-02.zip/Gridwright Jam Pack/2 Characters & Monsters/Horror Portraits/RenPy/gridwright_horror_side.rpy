# Gridwright Horror Portraits - side images for Ren'Py.
# Copy RenPy/1920x1080/images (or 1280x720/images) into your game/ folder and this file into game/.
# Then a line like   detective scared "Did you hear that?"   shows the scared side image.

define detective = Character("Detective", image="detective")
define student = Character("Student", image="student")
define vampire = Character("Vampire", image="vampire")

# The same expressions are named in every file: neutral, scared, terrified, crying, angry, creepy, possessed, hurt.
