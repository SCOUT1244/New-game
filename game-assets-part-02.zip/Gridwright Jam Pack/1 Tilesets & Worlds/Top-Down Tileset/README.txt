GRIDWRIGHT TOP-DOWN TILESET - FREE SAMPLE  v1.0
===============================================

143 tiles from the Gridwright Top-Down Tileset: grass, dirt and water ground, the 47-tile grass set,
the dirt corner set, one frame of the water set, the wood fence and six props.
Same grid, same file names and same licence as the full pack (1113 tiles and props).
demo_map_made_with_the_full_pack.gif shows what the full pack builds.

THE BITMASKS
  47-tile sets (terrain_blob_NNN.png): N=1, NE=2, E=4, SE=8, S=16, SW=32, W=64, NW=128.
  A diagonal counts only when the two neighbours next to it are set.
  Corner sets (terrain_corner_NN.png): NE=1, SE=2, SW=4, NW=8. Fences: N=1, E=2, S=4, W=8.
  tiles.json lists every tile with its sheet position and bitmask.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every tile is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
