GRIDWRIGHT PARALLAX BACKGROUNDS - FREE SAMPLE  v1.0
===================================================

A free taste of Gridwright Parallax Backgrounds: the Meadow and Ocean scenes in all 4 times of day (8 backgrounds), every layer at
1x, 2x, 4x, the merged pictures, backgrounds.json, the Godot scenes for these 8 and viewer.html.
The ocean's sea is animated (8 frames) and the night skies twinkle (4 frames).

The full pack has 12 scenes x 4 times = 48 backgrounds (300 layer images) at 1x, 2x, 3x, 4x and 6x.
Same licence as the full pack (LICENSE.txt). How to use the layers: see backgrounds.json ("how_to").

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
