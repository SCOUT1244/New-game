extends Node2D
## Gridwright Parallax Backgrounds: demo. Shows one background and scrolls the camera.
## Left / Right: previous / next background. Up / Down: faster / slower. Space: pause.
## Each background is its own scene in res://gridwright_parallax/scenes/ (Parallax2D layers): instance any of them.

const DIR := "res://gridwright_parallax/scenes/"

var files: Array[String] = []
var index := 0
var speed := 40.0
var current: Node = null
@onready var cam: Camera2D = $Camera2D


func _ready() -> void:
	for f in DirAccess.get_files_at(DIR):
		var name := f.trim_suffix(".remap")
		if name.ends_with(".tscn") and not files.has(name):
			files.append(name)
	files.sort()
	if "--test" in OS.get_cmdline_user_args():
		await _test()
		return
	_show(0)


func _show(i: int) -> void:
	index = wrapi(i, 0, files.size())
	if current:
		current.queue_free()
	current = load(DIR + files[index]).instantiate()
	add_child(current)
	move_child(current, 0)
	DisplayServer.window_set_title("Gridwright Parallax Backgrounds - " + files[index].trim_suffix(".tscn"))


func _process(delta: float) -> void:
	cam.position.x += speed * delta


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_right"):
		_show(index + 1)
	elif event.is_action_pressed("ui_left"):
		_show(index - 1)
	elif event.is_action_pressed("ui_up"):
		speed *= 1.5
	elif event.is_action_pressed("ui_down"):
		speed /= 1.5
	elif event.is_action_pressed("ui_accept"):
		speed = 0.0 if speed != 0.0 else 40.0


func _test() -> void:
	# loads every scene, counts its layers and textures, saves two screenshots, then quits
	var out := ""
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--out="):
			out = a.substr(6)
	var bad := 0
	for i in files.size():
		var scene: Node = load(DIR + files[i]).instantiate()
		var layers := 0
		var tex := 0
		for c in scene.get_children():
			if c is Parallax2D:
				layers += 1
				for s in c.get_children():
					if s is Sprite2D and s.texture:
						tex += 1
					elif s is AnimatedSprite2D and s.sprite_frames and s.sprite_frames.get_frame_count("default") > 1:
						tex += 1
		print("SCENE ", files[i], " layers=", layers, " textured=", tex)
		if layers == 0 or tex != layers:
			bad += 1
		scene.free()
	for pick in [["ocean_sunset.tscn", 0.0], ["city_night.tscn", 0.0], ["meadow_day.tscn", 900.0]]:
		_show(files.find(pick[0]))
		speed = 0.0
		cam.position.x = pick[1]
		for k in 6:
			await get_tree().process_frame
		if out != "":
			var img := get_viewport().get_texture().get_image()
			img.save_png(out + "/" + str(pick[0]).trim_suffix(".tscn") + ".png")
	print("RESULT scenes=", files.size(), " bad=", bad)
	get_tree().quit()
