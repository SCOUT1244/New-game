# Gridwright Visual Novel Backgrounds: image definitions for Ren'Py.
# 1. Copy the files of Backgrounds/3x (1920x1080 projects) or Backgrounds/2x (1280x720 projects)
#    into game/images/gridwright_bg/, and Animations/<same size>/rain/ into game/images/gridwright_bg/rain/.
# 2. Copy this file into game/.
# 3. In your script:  scene bg classroom day   /   show gw rain   /   scene bg basement night flicker

image bg classroom day = "images/gridwright_bg/classroom_day.png"
image bg classroom sunset = "images/gridwright_bg/classroom_sunset.png"
image bg street night = "images/gridwright_bg/street_night.png"
image bg street rain = "images/gridwright_bg/street_rain.png"

# rain over any outdoor scene (12 fps)
image gw rain:
    "images/gridwright_bg/rain/rain_00.png"
    pause 0.083
    "images/gridwright_bg/rain/rain_01.png"
    pause 0.083
    "images/gridwright_bg/rain/rain_02.png"
    pause 0.083
    "images/gridwright_bg/rain/rain_03.png"
    pause 0.083
    "images/gridwright_bg/rain/rain_04.png"
    pause 0.083
    "images/gridwright_bg/rain/rain_05.png"
    pause 0.083
    "images/gridwright_bg/rain/rain_06.png"
    pause 0.083
    "images/gridwright_bg/rain/rain_07.png"
    pause 0.083
    repeat
