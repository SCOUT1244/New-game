GRIDWRIGHT VISUAL NOVEL BACKGROUNDS - FREE SAMPLE  v1.0
=======================================================

A free taste of Gridwright Visual Novel Backgrounds: classroom_day, classroom_sunset, street_night, street_rain and the rain animation, at 640x360, 1280x720 and 1920x1080,
with the Ren'Py file for them. The full pack has 48 backgrounds of 14 locations:
https://gridwrightstudio.itch.io/pixel-art-visual-novel-backgrounds-renpy-day-night

HOW TO USE THEM
  Every background is a 16:9 picture drawn at 640x360 and shipped at:
    Backgrounds/1x  640x360     (pixel-perfect source; scale it yourself with nearest-neighbour filtering)
    Backgrounds/2x  1280x720    (Ren'Py's default 1280x720 projects)
    Backgrounds/3x  1920x1080   (1080p projects)
  File names: <scene>_<time>.png, times day, sunset, night (+ rain for outdoor scenes).

  Ren'Py: copy the files of the size you use into game/images/gridwright_bg/ (and the Animations folders of the
  same size into game/images/gridwright_bg/rain/ etc.), copy RenPy/gridwright_backgrounds.rpy into game/, then:
      scene bg classroom day
      scene bg street rain
      show gw rain
      scene bg basement night flicker
  The names match a project made with Gridwright Pixel VN UI (sold separately), but any Ren'Py project works.

  Other engines (Godot, Unity, GameMaker, TyranoBuilder, RPG Maker): use the PNG of your window size as a
  full-screen background; play the Animations frames at the fps in backgrounds.json.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
