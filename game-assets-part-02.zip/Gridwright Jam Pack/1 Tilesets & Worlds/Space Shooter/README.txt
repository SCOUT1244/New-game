GRIDWRIGHT SPACE SHOOTER - FREE SAMPLE  v1.0
============================================

28 sprites from Gridwright Space Shooter: the blue arrow ship with its banking frames and engine flame, two enemies,
the blue laser, a red enemy round, the small explosion, the power pick-up and the blue backgrounds. Same grid, file names
and licence as the full pack (185 sprites). made_with_the_full_pack.gif shows what the full pack builds.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every sprite is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
