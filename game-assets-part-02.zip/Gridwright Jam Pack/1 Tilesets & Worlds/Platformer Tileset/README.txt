GRIDWRIGHT PLATFORMER TILESET - FREE SAMPLE  v1.0
=================================================

66 pieces from the Gridwright Platformer Tileset: the 47-tile grass set, the wood platforms, one spike tile, a few props,
the spinning coin and two parallax layers. Same grid, file names and licence as the full pack (285 pieces).
made_with_the_full_pack.gif shows what the full pack builds.

THE BITMASK
  terrain_blob_NNN.png: N=1, NE=2, E=4, SE=8, S=16, SW=32, W=64, NW=128. A diagonal counts only when the two
  neighbours next to it are set. tiles.json lists every piece with its sheet position and bitmask.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every piece is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
