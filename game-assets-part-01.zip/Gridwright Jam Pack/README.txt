GRIDWRIGHT JAM PACK v1.1
Free pixel art game assets for Gridwright Jam #1 (and for any game after it).

75 packs in one download: the free sample of every Gridwright asset pack on itch.io today,
31,038 files. Tilesets, characters and monsters, game UI, icons, effects, music, sound effects and fonts.

THE JAM
  Gridwright Jam #1, November 13-23, 2026. The theme is announced when it starts.
  Use at least one asset from this pack (or any Gridwright pack) in your game, and credit "Art by Gridwright".
  Jam page: https://itch.io/jam/gridwright-jam-1
  Discord (find a team, ask questions, show your progress): https://discord.gg/CmXcSgBQ6V

WHAT IS INSIDE
Each folder is one pack's free sample, exactly as it is on that pack's own page, with its own README
(sizes, file names, sheets, JSON) and LICENSE. The folders are sorted by kind:

  Tilesets & Worlds
    Dungeon Tileset                   https://gridwrightstudio.itch.io/dungeon-tileset-16x16-pixel-art-top-down
    Farm                              https://gridwrightstudio.itch.io/farming-tileset-16x16-pixel-art-crops-animals
    Haunted Asylum                    https://gridwrightstudio.itch.io/horror-tileset-16x16-pixel-art-asylum-hospital-top-down
    Interiors                         https://gridwrightstudio.itch.io/interiors-tileset-16x16-pixel-art-furniture
    Isometric Castle & Siege          https://gridwrightstudio.itch.io/isometric-castle-siege-pixel-art-walls-towers-tileset
    Isometric Castle Interiors        https://gridwrightstudio.itch.io/isometric-castle-interiors-pixel-art-throne-room-dungeon
    Isometric City                    https://gridwrightstudio.itch.io/isometric-city-tileset-pixel-art-roads-buildings-cars
    Isometric Dungeon & Caves         https://gridwrightstudio.itch.io/isometric-dungeon-cave-mine-tileset-pixel-art-32x32
    Isometric Farm                    https://gridwrightstudio.itch.io/isometric-farm-tileset-pixel-art-crops-barn-windmill
    Isometric Graveyard & Crypt       https://gridwrightstudio.itch.io/isometric-graveyard-crypt-pixel-art-halloween-tileset
    Isometric Halloween Mini Pack     https://gridwrightstudio.itch.io/free-isometric-halloween-pixel-art-pumpkins-props
    Isometric Haunted Mansion         https://gridwrightstudio.itch.io/isometric-haunted-mansion-pixel-art-horror-interior-tileset
    Isometric Interiors               https://gridwrightstudio.itch.io/isometric-interiors-pixel-art-32x32-furniture-walls
    Isometric Survivor Base           https://gridwrightstudio.itch.io/isometric-survivor-base-pixel-art-hideout-loot-barricades
    Isometric Tiles                   https://gridwrightstudio.itch.io/isometric-tileset-pixel-art-32x32-blocks-buildings
    Isometric Wasteland               https://gridwrightstudio.itch.io/isometric-post-apocalyptic-tileset-pixel-art-ruins-wrecks
    Medieval Village                  https://gridwrightstudio.itch.io/medieval-village-tileset-16x16-pixel-art-fantasy
    Modern Office & Home              https://gridwrightstudio.itch.io/modern-office-home-tileset-16x16-pixel-art
    Modern Town                       https://gridwrightstudio.itch.io/modern-town-city-tileset-16x16-pixel-art-cars
    PSX Horror Textures               https://gridwrightstudio.itch.io/psx-horror-textures-seamless-ps1-retro-3d-64x64-128x128
    Parallax Backgrounds              https://gridwrightstudio.itch.io/pixel-art-parallax-backgrounds-seamless-day-night
    Platformer Tileset                https://gridwrightstudio.itch.io/platformer-tileset-16x16-pixel-art-parallax
    Sci-Fi Interiors                  https://gridwrightstudio.itch.io/sci-fi-spaceship-tileset-16x16-pixel-art-top-down
    Space Shooter                     https://gridwrightstudio.itch.io/space-shooter-sprites-16x16-pixel-art-shmup
    Top-Down Tileset                  https://gridwrightstudio.itch.io/top-down-tileset-16x16-pixel-art-autotiles
    Visual Novel Backgrounds          https://gridwrightstudio.itch.io/pixel-art-visual-novel-backgrounds-renpy-day-night

  Characters & Monsters
    Animals & Pets                    https://gridwrightstudio.itch.io/animals-pets-16x16-pixel-art-top-down-sprites
    Farm RPG                          https://gridwrightstudio.itch.io/farm-rpg-asset-pack-16x16-pixel-art-all-in-one
    Fish & Fishing                    https://gridwrightstudio.itch.io/pixel-art-fish-fishing-sprites-16x16-32x32-rods-ui
    Horror Monsters                   https://gridwrightstudio.itch.io/pixel-art-horror-monsters-48x48-side-view-enemies
    Horror Portraits                  https://gridwrightstudio.itch.io/pixel-art-horror-portraits-64x64-dialogue-renpy
    Isometric Animals                 https://gridwrightstudio.itch.io/isometric-animals-pixel-art-farm-wildlife-8-directions
    Isometric Army                    https://gridwrightstudio.itch.io/isometric-army-rts-units-pixel-art-8-directions-team-colors
    Isometric Character Creator       https://gridwrightstudio.itch.io/isometric-character-creator-pixel-art-modular-8-directions
    Isometric Characters              https://gridwrightstudio.itch.io/isometric-characters-pixel-art-8-directions-animated
    Isometric City People             https://gridwrightstudio.itch.io/isometric-city-people-pixel-art-pedestrians-npcs-8-directions
    Isometric Hero Creator            https://gridwrightstudio.itch.io/isometric-hero-creator-pixel-art-armor-weapons-8-directions
    Isometric Monsters                https://gridwrightstudio.itch.io/isometric-monsters-pixel-art-halloween-8-directions
    Isometric Zombies & Survivors     https://gridwrightstudio.itch.io/isometric-zombies-survivors-pixel-art-8-directions-animated
    Modern People                     https://gridwrightstudio.itch.io/modern-people-16x16-pixel-art-characters-layers
    Pixel Bosses                      https://gridwrightstudio.itch.io/pixel-art-boss-sprites-96x96-animated-monsters
    Pixel Monsters                    https://gridwrightstudio.itch.io/pixel-art-monsters-enemies-16x16-animated
    Pixel PNGTuber Avatars            https://gridwrightstudio.itch.io/pixel-art-pngtuber-avatars-twitch-vtuber-idle-blink-talk
    Pixel Portraits                   https://gridwrightstudio.itch.io/pixel-art-portraits-64x64-dialogue-expressions
    Side-View Characters              https://gridwrightstudio.itch.io/side-view-characters-32x32-pixel-art-platformer
    Top-Down Characters               https://gridwrightstudio.itch.io/top-down-rpg-characters-16x16-pixel-art
    Virtual Pet Kit                   https://gridwrightstudio.itch.io/virtual-pet-pixel-art-kit-eggs-care-ui-32x32

  Game UI
    Book & Journal UI                 https://gridwrightstudio.itch.io/pixel-art-book-ui-journal-page-turn-animation
    Cards & Dice                      https://gridwrightstudio.itch.io/pixel-art-playing-cards-dice-chips
    Casual Game UI                    https://gridwrightstudio.itch.io/casual-game-ui-pixel-art-32x32-mobile-buttons
    Cozy UI                           https://gridwrightstudio.itch.io/cozy-ui-pixel-art-16x16-farming-life-sim-gui
    Dark Fantasy UI                   https://gridwrightstudio.itch.io/dark-fantasy-ui-pixel-art-16x16-gothic-hud
    Deckbuilder Card UI               https://gridwrightstudio.itch.io/deckbuilder-card-ui-pixel-art-roguelike-card-battle-kit
    Fantasy RPG UI                    https://gridwrightstudio.itch.io/fantasy-rpg-ui-pixel-art-32x32-ornate
    Idle & Incremental UI             https://gridwrightstudio.itch.io/idle-incremental-game-ui-pixel-art-clicker-tycoon-icons
    Pixel VN UI for Ren'Py            https://gridwrightstudio.itch.io/pixel-art-renpy-gui-visual-novel-ui-kit
    Sci-Fi HUD                        https://gridwrightstudio.itch.io/sci-fi-hud-ui-pixel-art-32x32-radar-reticles
    Survival Horror UI                https://gridwrightstudio.itch.io/survival-horror-ui-pixel-art-16x16-inventory-hud
    UI Kit                            https://gridwrightstudio.itch.io/pixel-art-ui-gui-hud-kit-16x16

  Icons
    Food & Cooking Icons              https://gridwrightstudio.itch.io/food-icons-32x32-pixel-art-cooking-drinks
    RPG Item Icons                    https://gridwrightstudio.itch.io/rpg-item-icons-16x16-pixel-art
    Skill & Status Icons              https://gridwrightstudio.itch.io/skill-icons-32x32-pixel-art-buffs-debuffs

  VFX
    2D Lights & Glow                  https://gridwrightstudio.itch.io/2d-light-textures-pixel-art-glow-sprites-godot-unity
    Combat VFX                        https://gridwrightstudio.itch.io/combat-vfx-pixel-art-64x64-slash-hit-effects
    Horror VFX                        https://gridwrightstudio.itch.io/horror-vfx-pixel-art-vhs-overlays-blood-flashlight-effects
    Pixel VFX                         https://gridwrightstudio.itch.io/pixel-art-vfx-effects-sprite-sheets
    Screen Transitions                https://gridwrightstudio.itch.io/screen-transitions-godot-4-renpy-pixel-art-scene-transition-masks
    Spell VFX                         https://gridwrightstudio.itch.io/spell-vfx-pixel-art-64x64-magic-effects
    Weather FX                        https://gridwrightstudio.itch.io/pixel-art-weather-effects-rain-snow-fog-loops

  Music & Sound
    Chiptune Music                    https://gridwrightstudio.itch.io/chiptune-game-music-8-bit-16-bit-loops-stems
    Horror Sound Effects              https://gridwrightstudio.itch.io/horror-sound-effects-creepy-sfx-ambience-loops
    Retro Sound Effects               https://gridwrightstudio.itch.io/retro-sound-effects-8-bit-16-bit-game-sfx
    UI Sound Effects                  https://gridwrightstudio.itch.io/ui-sound-effects-menu-click-button-game-sfx-5-styles

  Fonts
    Pixel Fonts                       https://gridwrightstudio.itch.io/pixel-fonts-ttf-bmfont-5x7-3x5
    Pixel Fonts 2                     https://gridwrightstudio.itch.io/pixel-fonts-2-serif-arcade-rounded-accents-ttf-bmfont

Audio: OGG only here; each pack's own page has the WAV files too.

WANT THE FULL PACKS?
  All of them and our tools in one bundle for $20: the Gridwright Megabundle, https://itch.io/s/207198
  Need art made for your game? Order a custom pack: https://gridwright.store/custom?ref=jampack
  Every pack above also has a full version on its own itch.io page (link next to it): https://gridwrightstudio.itch.io

LICENCE (short): free to use and modify in personal and commercial games, during the jam and after.
Do not resell or redistribute the assets as assets. Full text: LICENSE.txt.
