GRIDWRIGHT ISOMETRIC HALLOWEEN MINI PACK - FREE SAMPLE  v1.0
============================================================

A part of Gridwright Isometric Halloween Mini Pack to try in your engine before you get it: 23 of its 162
pieces: a dead grass block and half block, a grave dirt floor tile, a toothy jack-o'-lantern facing sw (unlit,
and lit in 4 flame frames), a pile of gourds, black candles (unlit, and lit in 4 frames), a witch's hat, the
sheet ghost facing sw (4 frames) and the bats (4 frames), with the shadow sprite of each standing piece. At
1x, 2x and 3x, on sheets, with isometric.json for these sprites.

The full pack has 162 pieces and 25 shadow sprites: 12 blocks, 9 floors, 32 frames of ground mist, 42 pumpkin
pieces (3 jack-o'-lantern faces and a tower, each facing sw or se, unlit and lit; a giant pumpkin, gourds), 10
decorated tombstones, 15 candle and skull candle pieces, 14 props (broom, hat, candy buckets, corn shock,
potions, a spell circle) and 28 creature frames (a black cat, a ghost, a crow, a spider, bats, a zombie hand).

FILES
  PNG\<k>x\...\<name>.png        single sprites, the same folders and names as the full pack (1x, 2x, 3x)
  Sheets\<sheet>_<k>x.png + .json  the same sheets as the full pack, with only these sprites (x, y, w, h of each)
  isometric.json                 how to place every sprite: grid, size, anchor, footprint, shadow
  Palettes\                       the full pack's palette (.hex, .gpl)

Pixel art: turn off smoothing in your engine (Godot: Texture Filter = Nearest; Unity: Filter Mode = Point,
Compression = None; GameMaker: untick "interpolate colours").

LICENCE: the same as the full pack (LICENSE.txt). Use it in your games, commercial too; do not resell the files.
Credit is required: "Art by Gridwright" with a link.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
