GRIDWRIGHT ISOMETRIC GRAVEYARD & CRYPT - FREE SAMPLE  v1.0
==========================================================

103 sprites from Gridwright Isometric Graveyard & Crypt: graveyard-grass blocks, a crypt-stone block and floor, the 15
gravel-path pieces, the 16 iron-fence joins, thin ground mist (4 tiles x 8 frames), round and cross tombstones, an obelisk,
a fresh grave, a jack-o'-lantern (unlit and lit, 4 frames), a lantern post (unlit and lit), a twisted dead tree, a
yew, a pumpkin and six crypt-wall pieces, with their shadows. Same grid, file names, JSON and licence as the full
pack (393 pieces + 88 shadows). made_with_the_full_pack.gif shows what the full pack builds.

PLACING A SPRITE
  Cell (col, row) at height h: x = X0 + 16 * (col - row), y = Y0 + 8 * (col + row) - h. Draw the sprite at
  (x - anchor_x, y - anchor_y); the anchors are in isometric.json. A block is 16 px tall.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every piece is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
