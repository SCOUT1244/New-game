GRIDWRIGHT PSX HORROR TEXTURES - FREE SAMPLE v1.0
========================================

16 of the 154 textures of Gridwright PSX Horror Textures, each at 64x64 and 128x128, with their normal maps:
concrete, red brick, hospital tiles, damp wallpaper, wood floor, rusty metal, chain-link fence, checker linoleum,
broken ceiling tiles, night grass, a hospital door, a boarded window, an EXIT sign and three decals.

The full pack adds the rest of the 154 designs, atlases at 64/32/16 px for the Tile Modeler and other editors,
and a Godot 4 demo project with a PSX shader.

Use NEAREST / POINT filtering for the crisp PS1 look. Normal maps are OpenGL style (flip green for Unity/Unreal).
You may use the sample in personal and commercial games (LICENSE.txt). Do not redistribute it.

Full pack: https://gridwrightstudio.itch.io/psx-horror-textures-seamless-ps1-retro-3d-64x64-128x128

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
