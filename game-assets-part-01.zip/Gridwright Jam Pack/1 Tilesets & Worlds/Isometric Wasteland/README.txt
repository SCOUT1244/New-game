GRIDWRIGHT ISOMETRIC WASTELAND - FREE SAMPLE  v1.0
==================================================

147 sprites from Gridwright Isometric Wasteland: one block of each ground material and the toxic sludge (4 frames),
the 15 faded road pieces, four ground details, the red brick storeys (every ground and upper floor type, the
boarded ones also lit), all 16 roof joins and all 16 broken tops of the brick facade, a rusty red sedan in 4
directions and a burned one, all 16 sandbag wall joins, a tent, a campfire and a burning barrel (4 frames each),
supply crates, a drum, rubble, a dead tree, weeds and a barricade, with their shadows. Same grid, file names, JSON
and licence as the full pack (402 pieces + 140 shadows). made_with_the_full_pack.gif shows what
the full pack builds.

PLACING A SPRITE
  Cell (col, row) at height h: x = X0 + 16 * (col - row), y = Y0 + 8 * (col + row) - h. Draw the sprite at
  (x - anchor_x, y - anchor_y); the anchors are in isometric.json. A pavement block is 16 px tall, asphalt 14 px.
  Storeys are 20 px: storey k stands at the block's top + 20 * k. Roads, roofs, broken tops and walls join by
  neighbour mask: NE = 1, SE = 2, SW = 4, NW = 8.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every piece is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
