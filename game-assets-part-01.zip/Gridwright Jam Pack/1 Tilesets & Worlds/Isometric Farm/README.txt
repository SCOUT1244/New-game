GRIDWRIGHT ISOMETRIC FARM - FREE SAMPLE  v1.0
=============================================

56 sprites from Gridwright Isometric Farm: grass and farmyard floors, all 15 dry soil pieces, wheat and carrots
in 4 growth stages, the split-rail fence with its 16 joins, a chicken coop (2 views), a round hay bale, a
scarecrow, a well, a crate of apples and an apple tree, with their shadows. Same grid, file names, JSON and
licence as the full pack (163 pieces + 39 shadows). made_with_the_full_pack.gif shows what the
full pack builds.

PLACING A SPRITE
  Cell (col, row): x = X0 + 16 * (col - row), y = Y0 + 8 * (col + row). Draw the sprite at
  (x - anchor_x, y - anchor_y); the anchors are in isometric.json.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit is required: write "Art by Gridwright" with a link to https://gridwrightstudio.itch.io in your game's credits or on its store page. Not for AI training or NFTs.

HOW IT WAS MADE
  Every piece is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
