GRIDWRIGHT HAUNTED ASYLUM - FREE SAMPLE  v1.0
=============================================

71 pieces from Gridwright Haunted Asylum: the 47-tile ward wall set, the ward linoleum floors, a stain, papers and
moonlight, the ward door (4 frames), a barred window, the flickering tube light (4 frames), the HELP writing, beds,
a bedside table, an IV stand, a wheelchair and a doll. Same grid, file names and licence as the full pack
(407 pieces plus a lights-out version of each). made_with_the_full_pack.gif shows what the full pack builds.

THE BITMASK
  wall_ward_NNN.png: N=1, NE=2, E=4, SE=8, S=16, SW=32, W=64, NW=128. A diagonal counts only when the two neighbours
  next to it are set. tiles.json lists every piece with its sheet position and bitmask.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit is required: write "Art by Gridwright" with a link to https://gridwrightstudio.itch.io in your game's credits or on its store page. Not for AI training or NFTs.

HOW IT WAS MADE
  Every piece is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
