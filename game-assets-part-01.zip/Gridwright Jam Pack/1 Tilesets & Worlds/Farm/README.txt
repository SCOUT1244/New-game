GRIDWRIGHT FARM - FREE SAMPLE  v1.0
===================================

105 sprites from Gridwright Farm: the 47-tile dry soil set, 4 grass tiles, 4 crops with all 6 stages
(carrot, tomato, wheat, pumpkin) with their icons and seed packets, the white chicken (all 16 frames) and a few props
and tools. Same grid, file names and licence as the full pack (521 sprites).
made_with_the_full_pack.gif shows what the full pack builds.

THE BITMASK
  soil_dry_NNN.png: N=1, NE=2, E=4, SE=8, S=16, SW=32, W=64, NW=128. A diagonal counts only when the two neighbours
  next to it are set. farm.json lists every sprite with its sheet position.

CROPS
  Every crop frame is 16x32; the plant stands on the bottom 16x16 cell. Stages: _0 seeds, _1 sprout, _2 young,
  _3 growing, _4 ripe, _withered.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every sprite is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
