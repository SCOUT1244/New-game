GRIDWRIGHT ISOMETRIC CASTLE INTERIORS - FREE SAMPLE  v1.0
=========================================================

42 sprites from Gridwright Isometric Castle Interiors: flagstone, plank and carpet floors, the dressed ashlar wall set (full
and cut-away walls, corner, post, doorway, arrow slit), the oak door and a wall torch with their 4 frames, a
throne, a standing banner, a bench, a treasure chest, a barrel, a crate, a red runner, a wall banner and a shield,
with their shadows. Same grid, file names, JSON and licence as the full pack (267 pieces + 79
shadows). made_with_the_full_pack.gif shows what the full pack builds.

PLACING A SPRITE
  Cell (col, row): x = X0 + 16 * (col - row), y = Y0 + 8 * (col + row). Draw the sprite at
  (x - anchor_x, y - anchor_y); the anchors are in isometric.json. Walls stand on a cell's back edges.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit is required: write "Art by Gridwright" with a link to https://gridwrightstudio.itch.io in your game's credits or on its store page. Not for AI training or NFTs.

HOW IT WAS MADE
  Every piece is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
