GRIDWRIGHT ISOMETRIC HAUNTED MANSION - FREE SAMPLE  v1.0
========================================================

44 sprites from Gridwright Isometric Haunted Mansion: rotten boards, a broken floor and the worn chequer, the rotting
damask wall set (full and cut-away walls, corner, post, doorway, window), the creaky door with its 4 frames, the
rocking chair (4 frames), a sheet-covered armchair, a dusty bookshelf, a dead plant, a cobweb, the ghost and the
candelabra (4 frames each), with their shadows. Same grid, file names, JSON and licence as the full pack
(258 pieces + 70 shadows). made_with_the_full_pack.gif shows what the full pack builds.

PLACING A SPRITE
  Cell (col, row): x = X0 + 16 * (col - row), y = Y0 + 8 * (col + row). Draw the sprite at
  (x - anchor_x, y - anchor_y); the anchors are in isometric.json. Walls stand on a cell's back edges.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every piece is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
