GRIDWRIGHT ISOMETRIC CASTLE & SIEGE - FREE SAMPLE  v1.0
=======================================================

69 sprites from Gridwright Isometric Castle & Siege: courtyard and ashlar blocks and floors, a siege-mud block, the 15
mud-track pieces, all 16 joins of the grey curtain wall, a round tower and a roofed square tower, the grey gatehouse
(portcullis in 4 frames), a catapult, a red pavilion, a red banner pole (4 frames), a torch post (unlit and lit),
a weapon rack, a training dummy and catapult stones, with their shadows. Same grid, file names, JSON and licence as
the full pack (260 pieces + 46 shadows). made_with_the_full_pack.gif shows what the full pack
builds.

PLACING A SPRITE
  Cell (col, row) at height h: x = X0 + 16 * (col - row), y = Y0 + 8 * (col + row) - h. Draw the sprite at
  (x - anchor_x, y - anchor_y); the anchors are in isometric.json. A block is 16 px tall. Walls join by
  neighbour mask: NE = 1, SE = 2, SW = 4, NW = 8; towers and gates stand on a wall cell.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every piece is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
