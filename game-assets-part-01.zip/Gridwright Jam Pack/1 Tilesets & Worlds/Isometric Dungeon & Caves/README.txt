GRIDWRIGHT ISOMETRIC DUNGEON & CAVES - FREE SAMPLE  v1.0
========================================================

52 sprites from Gridwright Isometric Dungeon & Caves: cave-rock blocks and a floor, a dungeon-stone block and floor, a gold ore
block, all 15 rail pieces, cave water (4 frames), a mine cart full of gold, a large stalagmite, violet crystals,
glowing mushrooms, six cave-wall pieces and a gold ore wall, a wooden chest opening (4 frames) and a hook lantern
(unlit and lit, 4 frames), with their shadows. Same grid, file names, JSON and licence as the full pack
(337 pieces + 49 shadows). made_with_the_full_pack.gif shows what the full pack builds.

PLACING A SPRITE
  Cell (col, row) at height h: x = X0 + 16 * (col - row), y = Y0 + 8 * (col + row) - h. Draw the sprite at
  (x - anchor_x, y - anchor_y); the anchors are in isometric.json. A block is 16 px tall.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every piece is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
