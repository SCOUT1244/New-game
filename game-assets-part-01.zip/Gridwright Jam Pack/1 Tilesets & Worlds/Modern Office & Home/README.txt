GRIDWRIGHT MODERN OFFICE & HOME - FREE SAMPLE  v1.0
===================================================

68 pieces from Gridwright Modern Office & Home: the 47-tile painted wall set, the oak floors, the beige rug, a door,
a window, a desk, an office chair facing 4 ways and a plant. Same grid, file names and licence as the full pack
(342 pieces). made_with_the_full_pack.gif shows what the full pack builds.

THE BITMASK
  wall_paint_NNN.png: N=1, NE=2, E=4, SE=8, S=16, SW=32, W=64, NW=128. A diagonal counts only when the two neighbours
  next to it are set. tiles.json lists every piece with its sheet position and bitmask.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every piece is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
