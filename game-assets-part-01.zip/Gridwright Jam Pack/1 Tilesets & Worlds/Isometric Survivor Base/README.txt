GRIDWRIGHT ISOMETRIC SURVIVOR BASE - FREE SAMPLE  v1.0
======================================================

44 sprites from Gridwright Isometric Survivor Base: the plywood wall set (full and cut-away, a doorway and a boarded window),
concrete, plank and tarp floors, the barricade door (4 frames), bunk beds, a mattress, ammo crates, a camp table, a
folding chair, canned food, water bottles, a fuel can, a backpack and a map board, with their shadows. Same grid,
file names, JSON and licence as the full pack (253 pieces). made_with_the_full_pack.gif shows what the
full pack builds.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit is required: write "Art by Gridwright" with a link to https://gridwrightstudio.itch.io in your game's credits or on its store page. Not for AI training or NFTs.

HOW IT WAS MADE
  Every piece is modelled in code and rendered to pixel art by our own ray caster.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
