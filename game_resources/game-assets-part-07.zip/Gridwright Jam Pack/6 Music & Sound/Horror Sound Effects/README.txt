GRIDWRIGHT HORROR SOUND EFFECTS - FREE SAMPLE v1.0

56 sounds from Gridwright Horror Sound Effects: 30 designs from every group of the full pack
(one-shots in Dry and Reverb, 4 loops), WAV + OGG: a jumpscare, a stinger, a riser into a hit, a braam, footsteps
on wood, water and a creaking floor, a door creak, slam and knocks, chains, a metal groan, a music box, a bell,
a whisper texture, a ghost moan, a heartbeat, a gasp, radio tuning, a VHS tape stop, a flashlight, a flickering
light, two horror UI sounds, glass, thunder, a basement ambience, a dark drone, a fast heartbeat and radio static.

  soundboard.html                play the sample's sounds in your browser (offline)
  cue_sheet.csv / .json          length, peak, loudness and loop points of each file
  preview_reel_timestamps.txt    where each sound of the FULL pack is in the free preview reel (MP3 on the page)

The full pack has 419 sounds in 16 groups, including 31 seamless loops:
https://gridwrightstudio.itch.io/horror-sound-effects-creepy-sfx-ambience-loops

You may use these sample sounds in your own games, commercial ones included, under the same licence as the
full pack (LICENSE.txt). Do not resell or redistribute them as sounds.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
