GRIDWRIGHT UI SOUND EFFECTS - FREE SAMPLE v1.0
========================================

12 of the 47 sounds, each in all 5 styles (60 files, WAV + OGG):
click, hover, confirm, cancel, error, menu_open, toggle_on, type_blip_mid, notification, coin, level_up, unlock.
Open soundboard.html to hear them; preview_reel_every_sound.mp3 plays every sound of the full pack.

The full pack has all 47 sounds x 5 styles = 235 sounds, a cue sheet and the sound board.
You may use the sample in personal and commercial games (LICENSE.txt). Do not redistribute it.

Full pack: https://gridwrightstudio.itch.io/ui-sound-effects-menu-click-button-game-sfx-5-styles

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
