GRIDWRIGHT RETRO SOUND EFFECTS - FREE SAMPLE v1.0

74 sounds from Gridwright Retro Sound Effects: 37 designs, each in 8-bit and 16-bit, WAV + OGG,
from every group of the full pack (UI, blips, coins, power-ups, jumps, footsteps, lasers, explosions, hits,
hurt, death, melee, magic, teleport, doors, alarms with a loop, jingles, creatures, sci-fi, world, score).

  preview_reel_every_sound.mp3   all 704 sounds of the full pack, in order (9 minutes)
  preview_reel_timestamps.txt    where each sound is in the reel
  soundboard.html                play the sample's sounds in your browser (offline)
  cue_sheet.csv / .json          length, peak, loudness and loop points of each file

The full pack has 704 sounds in 21 groups, including 12 seamless loops:
https://gridwrightstudio.itch.io/retro-sound-effects-8-bit-16-bit-game-sfx

You may use these sample sounds in your own games, commercial ones included, under the same licence as the
full pack (LICENSE.txt). Do not resell or redistribute them as sounds.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
