GRIDWRIGHT CHIPTUNE MUSIC - FREE SAMPLE v1.0

2 complete tracks (Open Road, Market Square) and 3 jingles (Level Complete, Game Over, Item Get) from Gridwright Chiptune Music,
each in 8-bit and 16-bit, with every version the full pack has: loop, intro + loop, full, calm and 4 stems
(OGG), loops, intro loops and jingles also as WAV. 52 files.

  player.html     listen to them in your browser (offline)
  music.json      key, BPM, bars, loop points, loudness of every file
  cue_sheet.csv   the same as a table

The full pack has 10 tracks and 12 jingles, each in both versions:
https://gridwrightstudio.itch.io/chiptune-game-music-8-bit-16-bit-loops-stems

You may use the sample in your own games, commercial ones included, under the same licence as the full pack
(LICENSE.txt). Do not resell or redistribute it as music.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
