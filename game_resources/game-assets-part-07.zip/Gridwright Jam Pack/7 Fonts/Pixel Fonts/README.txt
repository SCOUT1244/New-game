GRIDWRIGHT PIXEL FONTS - FREE SAMPLE  v1.0
==========================================

One font from the Gridwright Pixel Fonts: Gridwright Tiny, a 3x5 capitals font for HUD numbers and small labels.
TTF plus bitmap font (PNG + BMFont .fnt) at 1x, 2x and 3x. 95 ASCII characters; lowercase shows the capital shapes.
Use it at 6 px or a whole multiple (12, 18, ...), with smoothing off.
The full pack has 6 fonts; all_fonts_in_the_full_pack.png shows them.

LICENCE (the full text is in LICENSE.txt)
  Use the font in personal and commercial projects, and embed it in your game or app.
  Do not resell or redistribute the font files. Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  The letter shapes were placed pixel by pixel and turned into fonts by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
