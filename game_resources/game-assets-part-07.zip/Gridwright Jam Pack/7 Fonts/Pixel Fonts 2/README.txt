﻿GRIDWRIGHT PIXEL FONTS 2 - FREE SAMPLE  v1.0
============================================

One complete font from the Gridwright Pixel Fonts 2: Gridwright Micro, a tiny HUD font with real lowercase.
Capitals 6 px high and mostly 3 px wide, lowercase 4 px high. All 176 characters: ASCII plus Western European accents.
TTF plus bitmap font (PNG + BMFont .fnt) at 1x, 2x and 3x.
Use it at 11 px or a whole multiple (22, 33, ...), with smoothing off.
The full pack has 12 fonts; all_fonts_in_the_full_pack.png shows them.

LICENCE (the full text is in LICENSE.txt)
  Use the font in personal and commercial projects, and embed it in your game or app.
  Do not resell or redistribute the font files. Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  The letter shapes were placed pixel by pixel and turned into fonts by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
