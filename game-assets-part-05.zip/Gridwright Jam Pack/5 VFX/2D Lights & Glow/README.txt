GRIDWRIGHT 2D LIGHTS & GLOW - FREE SAMPLE  v1.0
===============================================

From Gridwright 2D Lights & Glow, in both styles (pixel, smooth) and both formats (alpha, add): the soft radial
light at 128 and 256, the lamp halo at 128, the flashlight cone at 256, the four-pane window shaft at 256, a light
pool, the animated torch and candle, the warm tinted glows and the 640x360 vignette. Same names, folders and
lights.json as the full pack. made_with_the_full_pack.gif shows every animated light of the full pack.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit is required: write "Art by Gridwright" with a link to https://gridwrightstudio.itch.io in your game's credits or on its store page. Not for AI training or NFTs.

HOW IT WAS MADE
  Every light is computed by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
