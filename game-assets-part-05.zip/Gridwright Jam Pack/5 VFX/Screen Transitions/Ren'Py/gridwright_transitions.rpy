# Gridwright Screen Transitions for Ren'Py 7.5 / 8.x
# Copy Masks/1920x1080 (or Masks/1280x720) into game/gridwright_transitions/ (keep the size folder),
# put this file into game/, then:  scene bg street with gw_iris_circle
# Dark pixels change first (reverse=True). gw_transition("spiral", 0.8) makes one with another time.

init 5 python:
    def gw_transition(name, time=1.0, ramplen=16):
        size = "%dx%d" % (config.screen_width, config.screen_height)
        return ImageDissolve("gridwright_transitions/%s/%s.png" % (size, name), time, ramplen, reverse=True)

    gw_wipe_right = gw_transition("wipe_right")
    gw_iris_circle = gw_transition("iris_circle")
    gw_iris_heart = gw_transition("iris_heart")
    gw_diamonds_left = gw_transition("diamonds_left")
    gw_blinds_horizontal = gw_transition("blinds_horizontal")
    gw_clock = gw_transition("clock")
    gw_pixel_dissolve = gw_transition("pixel_dissolve")
    gw_noise_wipe = gw_transition("noise_wipe")
