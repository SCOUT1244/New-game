## The second scene of the demo: any key goes back with a transition.
extends Control


func _ready() -> void:
	var bg := TextureRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	bg.texture = preload("res://demo/scene_b.png")
	add_child(bg)
	var label := Label.new()
	label.position = Vector2(16, 16)
	label.text = "Scene B (changed with Transition.change_scene). Press any key to go back."
	add_child(label)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not Transition.busy:
		Transition.change_scene("res://demo/demo.tscn", "iris_circle")
