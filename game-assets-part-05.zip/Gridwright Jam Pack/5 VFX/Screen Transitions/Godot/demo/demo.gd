## Gridwright Screen Transitions demo.
## Left / Right: choose a transition.  Space: play it.  P: pixel art / smooth.
## I: invert.  C: colour.  X: pixelate on/off.  Enter: change to another scene with it.
extends Control

const PICTURES := [preload("res://demo/scene_a.png"), preload("res://demo/scene_b.png")]
const COLOURS := [Color.BLACK, Color.WHITE, Color("8a66ff"), Color("c0283c")]

var index := 0
var picture := 0
var colour := 0
var invert := false
var pixelate := false
var _bg: TextureRect
var _label: Label


func _ready() -> void:
	_bg = TextureRect.new()
	_bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	_bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	_bg.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_bg.texture = PICTURES[picture]
	add_child(_bg)
	_label = Label.new()
	_label.position = Vector2(16, 16)
	_label.add_theme_color_override("font_outline_color", Color.BLACK)
	_label.add_theme_constant_override("outline_size", 6)
	add_child(_label)
	_show()


func _show() -> void:
	var names: PackedStringArray = Transition.mask_names()
	_label.text = "%d / %d   %s   (%s%s%s)\nLeft/Right choose   Space play   P pixel art   I invert   C colour   X pixelate   Enter change scene" % [
		index + 1, names.size(), names[index],
		"pixel art" if Transition.pixel_art else "smooth",
		", inverted" if invert else "", ", pixelate" if pixelate else ""]


func _opts() -> Dictionary:
	return {"color": COLOURS[colour], "invert": invert, "pixelate": 24.0 if pixelate else 0.0}


func _unhandled_input(event: InputEvent) -> void:
	if not event.is_pressed() or Transition.busy:
		return
	var names: PackedStringArray = Transition.mask_names()
	if event.is_action("ui_right"):
		index = (index + 1) % names.size()
	elif event.is_action("ui_left"):
		index = (index - 1 + names.size()) % names.size()
	elif event.is_action("ui_accept") and event is InputEventKey and event.keycode == KEY_ENTER:
		Transition.change_scene("res://demo/scene_b.tscn", names[index], _opts())
		return
	elif event.is_action("ui_accept"):
		_play(names[index])
	elif event is InputEventKey:
		match event.keycode:
			KEY_P: Transition.pixel_art = not Transition.pixel_art
			KEY_I: invert = not invert
			KEY_C: colour = (colour + 1) % COLOURS.size()
			KEY_X: pixelate = not pixelate
	_show()


func _play(mask: String) -> void:
	await Transition.cover(mask, _opts())
	picture = 1 - picture
	_bg.texture = PICTURES[picture]
	await Transition.reveal(mask, _opts())
