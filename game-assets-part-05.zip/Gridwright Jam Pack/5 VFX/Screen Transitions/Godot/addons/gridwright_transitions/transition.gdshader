// Gridwright Screen Transitions: one shader for every mask.
// A mask is a grayscale picture: dark pixels are covered first, white last.
// progress 0 = nothing covered, 1 = everything covered.
shader_type canvas_item;

uniform sampler2D mask : hint_default_white, filter_linear;
// the same mask read with nearest filtering (pixel art masks, hard edges)
uniform sampler2D mask_pixel : hint_default_white, filter_nearest;
uniform bool pixel_mode = false;
uniform float progress : hint_range(0.0, 1.0) = 0.0;
// 0 = hard pixel edge (use the 320x180 masks with nearest filtering for pixel art)
uniform float smoothness : hint_range(0.0, 0.5) = 0.08;
uniform vec4 fill_color : source_color = vec4(0.0, 0.0, 0.0, 1.0);
uniform bool use_fill_texture = false;
uniform sampler2D fill_texture : hint_default_white;
uniform bool invert = false;
uniform bool flip_h = false;
uniform bool flip_v = false;
// > 0: the part that is not covered yet is pixelated more and more as progress rises
uniform float pixelate : hint_range(0.0, 64.0) = 0.0;
uniform sampler2D screen_tex : hint_screen_texture, filter_nearest;

void fragment() {
	vec2 uv = UV;
	if (flip_h) { uv.x = 1.0 - uv.x; }
	if (flip_v) { uv.y = 1.0 - uv.y; }
	float m = pixel_mode ? texture(mask_pixel, uv).r : texture(mask, uv).r;
	if (invert) { m = 1.0 - m; }
	float a;
	if (smoothness < 0.001) {
		a = step(m, progress * 1.004 - 0.002);
	} else {
		float p = progress * (1.0 + smoothness);
		a = 1.0 - smoothstep(p - smoothness, p, m);
	}
	vec4 fill = fill_color;
	if (use_fill_texture) { fill *= texture(fill_texture, UV); }
	if (pixelate > 0.0) {
		vec2 cell = SCREEN_PIXEL_SIZE * max(1.0, floor(1.0 + pixelate * progress));
		vec2 suv = (floor(SCREEN_UV / cell) + 0.5) * cell;
		vec3 under = texture(screen_tex, suv).rgb;
		COLOR = vec4(mix(under, fill.rgb, a * fill.a), 1.0);
	} else {
		COLOR = vec4(fill.rgb, fill.a * a);
	}
}
