## Gridwright Screen Transitions: the "Transition" autoload.
##
##   await Transition.change_scene("res://levels/level_2.tscn", "diamonds_left")
##   await Transition.cover("iris_circle")      # screen goes black
##   await Transition.reveal("iris_circle")     # and back
##
## A mask is a name from masks/ ("iris_circle") or any Texture2D you made yourself.
## Options (a Dictionary, all optional): color, smoothness, invert, flip_h, flip_v,
## pixel_art, fill_texture, pixelate, duration, reveal_mask, same_direction.
extends CanvasLayer

signal covered
signal finished

const MASK_DIR := "res://addons/gridwright_transitions/masks/"
const NAMES := ["wipe_right", "iris_circle", "iris_heart", "diamonds_left", "blinds_horizontal", "clock", "pixel_dissolve", "noise_wipe"]

@export var default_mask := "diamonds_left"
@export var duration := 0.6
@export var color := Color.BLACK
@export var smoothness := 0.08
## true: use the 320x180 masks with nearest filtering and hard edges (pixel art games)
@export var pixel_art := false

var busy := false
var _rect: ColorRect
var _mat: ShaderMaterial
var _tween: Tween


func _ready() -> void:
	layer = 128
	process_mode = Node.PROCESS_MODE_ALWAYS
	_rect = ColorRect.new()
	_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mat = ShaderMaterial.new()
	_mat.shader = preload("res://addons/gridwright_transitions/transition.gdshader")
	_rect.material = _mat
	_rect.visible = false
	add_child(_rect)
	set_progress(0.0)


## The mask texture for a name ("iris_circle") or a Texture2D.
func mask_texture(mask, pixel := pixel_art) -> Texture2D:
	if mask is Texture2D:
		return mask
	var folder := "320x180" if pixel else "1920x1080"
	return load(MASK_DIR + folder + "/" + str(mask) + ".png")


## Every mask name that ships with the add-on (also works in exported games).
func mask_names() -> PackedStringArray:
	return PackedStringArray(NAMES)


## Set the mask and options without animating (progress stays where it is).
func setup(mask = null, opts := {}) -> void:
	var pixel: bool = opts.get("pixel_art", pixel_art)
	var tex := mask_texture(mask if mask != null else default_mask, pixel)
	_mat.set_shader_parameter("mask", tex)
	_mat.set_shader_parameter("mask_pixel", tex)
	_mat.set_shader_parameter("pixel_mode", pixel)
	_mat.set_shader_parameter("smoothness", 0.0 if pixel else float(opts.get("smoothness", smoothness)))
	_mat.set_shader_parameter("fill_color", opts.get("color", color))
	_mat.set_shader_parameter("invert", bool(opts.get("invert", false)))
	_mat.set_shader_parameter("flip_h", bool(opts.get("flip_h", false)))
	_mat.set_shader_parameter("flip_v", bool(opts.get("flip_v", false)))
	_mat.set_shader_parameter("pixelate", float(opts.get("pixelate", 0.0)))
	var fill = opts.get("fill_texture", null)
	_mat.set_shader_parameter("use_fill_texture", fill != null)
	if fill != null:
		_mat.set_shader_parameter("fill_texture", fill)


## 0 = nothing covered, 1 = all covered. Call it yourself to drive a transition by hand.
func set_progress(p: float) -> void:
	_mat.set_shader_parameter("progress", clampf(p, 0.0, 1.0))
	_rect.visible = p > 0.0 or busy


## Covers the screen with the mask. await it.
func cover(mask = null, opts := {}) -> void:
	busy = true
	setup(mask, opts)
	await _run(0.0, 1.0, float(opts.get("duration", duration)))
	covered.emit()


## Uncovers the screen. With same_direction (default) the pixels that were covered
## first are uncovered first, so a left-to-right wipe keeps going left to right.
func reveal(mask = null, opts := {}) -> void:
	busy = true
	var o := opts.duplicate()
	if o.get("same_direction", true):
		o["invert"] = not bool(o.get("invert", false))
	setup(mask, o)
	await _run(1.0, 0.0, float(opts.get("duration", duration)))
	busy = false
	_rect.visible = false
	finished.emit()


## Covers, changes to the scene at path, uncovers. await it.
func change_scene(path: String, mask = null, opts := {}) -> Error:
	await cover(mask, opts)
	var err := get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame
	await reveal(opts.get("reveal_mask", mask), opts)
	return err


## The same with a PackedScene you already loaded.
func change_scene_packed(scene: PackedScene, mask = null, opts := {}) -> Error:
	await cover(mask, opts)
	var err := get_tree().change_scene_to_packed(scene)
	await get_tree().process_frame
	await get_tree().process_frame
	await reveal(opts.get("reveal_mask", mask), opts)
	return err


func _run(from: float, to: float, time: float) -> void:
	if _tween:
		_tween.kill()
	set_progress(from)
	_tween = create_tween()
	_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	_tween.tween_method(set_progress, from, to, maxf(time, 0.001))
	await _tween.finished
