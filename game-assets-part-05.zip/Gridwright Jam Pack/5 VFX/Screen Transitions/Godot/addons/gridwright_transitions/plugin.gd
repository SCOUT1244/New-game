@tool
extends EditorPlugin

const AUTOLOAD := "Transition"


func _enable_plugin() -> void:
	add_autoload_singleton(AUTOLOAD, "res://addons/gridwright_transitions/transition.gd")


func _disable_plugin() -> void:
	remove_autoload_singleton(AUTOLOAD)
