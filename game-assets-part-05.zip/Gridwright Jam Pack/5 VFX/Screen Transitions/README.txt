GRIDWRIGHT SCREEN TRANSITIONS - FREE SAMPLE v1.0
===========================================
8 screen transitions as grayscale masks, a Godot 4 add-on, a Ren'Py file and
pre-rendered frames for any engine.
This free sample has 8 of the 55 transitions, the Godot add-on and the
Ren'Py file. The full pack: https://gridwrightstudio.itch.io/screen-transitions-godot-4-renpy-pixel-art-scene-transition-masks


HOW A MASK WORKS
  Dark pixels are covered first, white pixels last. At progress p (0..1) every pixel whose
  value / 255 is <= p is covered. Every mask is equalised: at progress 0.5 exactly half the
  screen is covered, so all transitions run at the same even speed.
  Play it backwards (or invert the mask) to uncover the screen.

FOLDERS
  Masks/320x180/     pixel art version: sample with NEAREST filtering, hard edge (6x = 1080p exactly)
  Masks/1280x720/    smooth version for 720p games and Ren'Py at 1280x720
  Masks/1920x1080/   smooth version (use a soft edge of about 0.05-0.1)
  Frames/            <name>_sheet.png: 16 frames (4 x 4, 320x180 each), black with alpha,
                     frame k = progress k/15. For engines without shaders: scale up by 4 or 6.
  Preview/           a GIF of every transition
  Godot/             a Godot 4.4+ project with the add-on and a demo
  Ren'Py/            gridwright_transitions.rpy
  viewer.html        open it in a browser to try every transition
  transitions.json   every transition's name, group, description and files

THE TRANSITIONS
  wipes      wipe_right
  irises     iris_circle, iris_heart
  tiles      diamonds_left
  blinds     blinds_horizontal
  radial     clock
  dissolves  pixel_dissolve, noise_wipe

GODOT 4.4+
  1. Copy Godot/addons/gridwright_transitions into your project's addons/ folder.
  2. Project > Project Settings > Plugins: enable "Gridwright Screen Transitions".
     (This adds the autoload "Transition".)
  3. In any script:
       await Transition.change_scene("res://levels/level_2.tscn", "diamonds_left")
       await Transition.cover("iris_circle")              # to black
       await Transition.reveal("iris_circle")             # and back
       await Transition.change_scene(path, "spiral", {"color": Color.WHITE, "duration": 0.8})
     Options: color, duration, smoothness (0 = hard), invert, flip_h, flip_v, pixel_art
     (uses the 320x180 masks with nearest filtering), fill_texture (any Texture2D instead of a
     colour), pixelate (pixelates the part not yet covered), reveal_mask, same_direction.
     Set Transition.pixel_art = true once for a pixel art game.
     Spiral, clock, double clock and pinwheel sweep a whole ring per step, so they look best with
     a hard edge or a smoothness of 0.02 or less.
     A mask can also be your own Texture2D. Transition.mask_names() lists the built-in ones.
  4. Or use the shader alone: transition.gdshader on a full-screen ColorRect; set "mask"
     and animate "progress".
  The demo (open Godot/project.godot, press F5): Left/Right choose, Space play, P pixel art,
  I invert, C colour, X pixelate, Enter change scene.
  Tested by our build in Godot 4.7.2: every mask loads, the shader covers the share of the
  screen the progress asks for, change_scene() changes the scene and hides the overlay.

REN'PY 7.5 / 8.x
  Copy Masks/1920x1080 (or Masks/1280x720, the size of your game) into
  game/gridwright_transitions/ keeping the size folder, so you have
  game/gridwright_transitions/1920x1080/iris_circle.png. Put gridwright_transitions.rpy into game/.
      scene bg street with gw_iris_circle
      show eileen happy with gw_transition("spiral", 0.6)
  (ImageDissolve with reverse=True, so the dark pixels change first, like everywhere else.)

UNITY, GAMEMAKER, DEFOLD, LOVE, MONOGAME, WEB
  Any shader can use a mask: sample it at the screen UV and cover the pixel when
      mask.r <= progress          (hard)   or
      alpha = 1 - smoothstep(p - s, p, mask.r) with p = progress * (1 + s)   (soft edge s)
  Unity UI: put a full-screen Image with a material whose shader does the line above
  (or use the mask as an alpha-cutoff texture and animate the cutoff from 1 to 0).
  GameMaker: draw the mask with a shader, or play the frame sheets in Frames/ as a sprite.
  No shader at all: the frame sheets in Frames/ are ready-made animations.

LICENCE
  See LICENSE.txt. Use them in personal and commercial games; do not resell the assets.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
