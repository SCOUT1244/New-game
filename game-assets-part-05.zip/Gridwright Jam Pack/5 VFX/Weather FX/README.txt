GRIDWRIGHT WEATHER FX - FREE SAMPLE  v1.0
=========================================

A part of Gridwright Weather FX: the overlays rain_medium, splash_medium, snow_light, leaves_autumn; the sprites splash, leaf_orange, lightning_bolt_a, lightning_impact; the
icons sunny, rain, thunderstorm, snow, fog, windy. Same tiles, sheets, JSON and licence as the full pack
(33 overlays, 35 sprites, 36 icons, 8 tints, 18 presets).
made_with_the_full_pack.gif shows the full pack in a scene.

HOW THE OVERLAYS WORK
  Each overlay is a 128x128 tile: repeat it across the screen and play the frames in a loop; it has no seam in
  space or time. Draw the splashes under the rain. weather.json lists fps, opacity and blend.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every frame is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
