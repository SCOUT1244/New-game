GRIDWRIGHT SPELL VFX - FREE SAMPLE  v1.0
========================================

23 animations from Gridwright Spell VFX (102 frames): the fire projectile in all 8 directions, the
fire impact, the frost beam (start, body and end in 4 directions), the lightning strike and the holy shield loop.
Same cells, sheet layout, file names, JSON and licence as the full pack (224 animations, 1096 frames,
8 elements, plus element icons). made_with_the_full_pack.gif shows the full pack in a scene.

THE SHEETS
  Sheets\1x\<effect>_<element>.png: columns = frames, rows = directions (projectiles: right, down_right, down,
  down_left, left, up_left, up, up_right; beams: <direction>_start, _body, _end), and a JSON with every frame's
  rectangle, fps, loop, the anchor and the hit frames. effects.json lists them all. Every frame is also its own PNG
  in Frames\. Beams: start on the hand, bodies every 64 px, then the end; play the same frame on every piece.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every frame is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
