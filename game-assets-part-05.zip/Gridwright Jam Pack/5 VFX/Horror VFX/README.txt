GRIDWRIGHT HORROR VFX - FREE SAMPLE  v1.0
=========================================

A free taste of Gridwright Horror VFX: the overlays vhs_tracking, blood_drips, flashlight_medium, film_grain and the sprite effects
ghost_wisp_spectral, cursed_fire_cursed, jumpscare_burst_blood, with the same frames, sheets and JSON as the full pack.

The full pack has 34 overlays and 44 sprite animations (610 frames):
https://gridwrightstudio.itch.io/horror-vfx-pixel-art-vhs-overlays-blood-flashlight-effects

HOW TO USE THEM
  The overlays are drawn at 320x180 (a 16:9 pixel screen) and shipped at 1x (320x180), 2x (640x360) and
  6x (1920x1080) as single frames, plus frame sheets at 1x and 2x with a JSON (frame rectangles, fps, loop,
  opacity, blend). Use the size that matches your window, or the 1x frames stretched with nearest-neighbour
  filtering. Alpha is 1-bit: soft edges are pixel dithering, so they stay crisp at any whole-number scale.
  Flashlight masks are twice the screen (640x360 at 1x, up to 3840x2160 at 6x): centre the mask on your player
  and the light hole follows anywhere on the screen without the edges showing.

  Godot 4:  a CanvasLayer (layer 10) with a TextureRect (anchors Full Rect, stretch mode Scale, texture filter
            Nearest) per overlay, or an AnimatedSprite2D using the sheet; set Modulate alpha to the opacity and a
            CanvasItemMaterial with Blend Mode Add for "add" overlays. Flashlight: a Sprite2D on the CanvasLayer
            whose position follows the player's screen position.
  Unity:    a Screen Space - Overlay canvas with a RawImage (or Image) stretched to the screen, Point filtering,
            and a small script that swaps the frames at the given fps; colour alpha = opacity.
  GameMaker: draw_sprite_stretched(spr, frame, 0, 0, display_get_gui_width(), display_get_gui_height()) in the
            Draw GUI event, with draw_set_alpha(opacity); gpu_set_blendmode(bm_add) for "add" overlays.
  Ren'Py:   an ATL image (image vhs: "vhs_tracking_00.png" / pause 0.083 / "vhs_tracking_01.png" / ... / repeat)
            shown with "show vhs onlayer overlay"; the 6x frames are 1920x1080, the 2x frames 640x360.
  RPG Maker MZ: show the frames as pictures at 1920x1080 or 640x360, or use an animated-overlay plugin.

PRESETS (stack bottom to top)
  (the full pack lists 12 presets)

TINTS (multiply the whole picture under the overlays)
  vhs_warm    multiply #e8d8c0: washed-out home video
  cold_dread  multiply #a8b8d8: cold blue night, a ghost near
  sick_green  multiply #b8d0a0: poison, sickness, old fluorescent light
  blood_moon  multiply #e0a0a0: red danger, low health, a blood moon
  nightmare   multiply #9a8ab8: dream, nightmare, the other side

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
