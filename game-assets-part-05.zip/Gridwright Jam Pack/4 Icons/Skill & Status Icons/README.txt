GRIDWRIGHT SKILL & STATUS ICONS - FREE SAMPLE  v1.0
===================================================

A free taste of Gridwright Skill & Status Icons: 45 sprites at 1x, 2x and 3x, with the same folders, names and JSON maps
as the full pack: the Fire school's 8 skill icons (32x32) and their locked versions, 3 rarity frames,
the selected glow, the cooldown sweep, and 8 status effects (16x16) framed and plain.

The full pack has 80 skill icons in 10 schools (Warrior, Ranger, Rogue, Fire, Frost, Storm, Nature, Holy, Shadow, Arcane), each also locked,
40 status effects, 6 rarity frames, the lock, an empty slot and stack counts 1-9: 269 sprites.

Licence: the same as the full pack (LICENSE.txt): use it in your games, commercial ones too; don't resell the files.
Made by code. No third-party art.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
