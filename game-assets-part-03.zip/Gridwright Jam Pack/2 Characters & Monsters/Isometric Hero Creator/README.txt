GRIDWRIGHT ISOMETRIC HERO CREATOR - FREE SAMPLE  v1.0
=====================================================

A taste of Gridwright Isometric Hero Creator: two complete ready-made heroes (the Knight, broad build, plate armour with a sword and kite
shield, and the Huntress, slim build, with a bow) with all 11 animations in all 8 directions, the layer files they are
made of plus a few more, the arrow in 8 directions, layers.json and compose.py, so you can try the whole layer
workflow in your engine. The full pack has 508 layer files (bodies in 6 skin tones, 7 chest armours,
4 legs, 2 boots, 2 gloves, 3 shoulders, 2 capes, 9 helmets, 10 hairstyles in 8 colours, 3 beards and 12 weapon sets in
3 finishes, for both builds), 20 ready-made heroes and three magic bolts with impacts. made_with_the_full_pack.gif shows
the full pack on Gridwright Isometric Tiles (sold separately).

TRY IT
  python compose.py --list
  python compose.py --character knight --scale 2 --frames
  Layers\<build>\<group>\*.png: 8 rows (s, sw, w, nw, n, ne, e, se) x 63 columns of 64x64; layers.json
  gives each animation's first column, fps, loop, hit and spawn frames, the feet point (32, 46) and the layer order.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every frame is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
