GRIDWRIGHT ISOMETRIC ARMY - FREE SAMPLE  v1.0
=============================================

One unit from Gridwright Isometric Army, complete: the Swordsman in all 4 team colours. All its animations (idle 4, walk 8, run 6, attack 7, block 4, hurt 3, death 7) in
all 8 directions, with the same sheets, JSON, team colours, shadow sprites and licence as the full pack (10
units x 4 teams, 12,000 frames). made_with_the_full_pack.gif shows the full pack on Gridwright Isometric Tiles
and Isometric Castle & Siege (sold separately).

THE SHEETS
  Sheets\1x\<unit>_<team>\<unit>_<team>_<animation>.png: 8 rows (s, sw, w, nw, n, ne, e, se) of 64x64 cells, and a
  JSON with fps, loop, the anchor (32, 46), the attack's hit frame and hit box per direction and the walk and run speed
  per direction. Every frame is also its own PNG in PNG\, a folder per direction. Placement rules and the team
  colours: characters.json.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every frame is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
