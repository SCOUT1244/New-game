GRIDWRIGHT ISOMETRIC CHARACTERS - FREE SAMPLE  v1.0
===================================================

One character from Gridwright Isometric Characters: the Knight, complete. All its animations (idle, walk, run, attack,
block, hurt, death: 39 frames per direction) in all 8 directions, with the same sheets, JSON,
shadow sprite and licence as the full pack (10 characters, 2864 frames, an arrow and two
magic bolts). made_with_the_full_pack.gif shows the full pack on Gridwright Isometric Tiles (sold separately).

THE SHEETS
  Sheets\1x\knight\knight_<animation>.png: 8 rows (s, sw, w, nw, n, ne, e, se) of 64x64 cells, and knight.json
  with fps, loop, the feet point (32, 46), the attack's hit frame and hit box per direction and the walk and run
  speed per direction. Every frame is also its own PNG in PNG\. Placement rules: characters.json.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every frame is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
