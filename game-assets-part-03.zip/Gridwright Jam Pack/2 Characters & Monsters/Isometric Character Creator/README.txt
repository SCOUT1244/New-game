GRIDWRIGHT ISOMETRIC CHARACTER CREATOR - FREE SAMPLE  v1.0
==========================================================

A taste of Gridwright Isometric Character Creator: two complete ready-made characters (the Jogger, broad build, and the Barista, slim
build) with all 10 animations in all 8 directions, the layer files they are made of plus a few more, layers.json and
compose.py, so you can try the whole layer workflow in your engine. The full pack has 452 layer files
(bodies in 6 skin tones, 10 hairstyles in 8 colours, 10 tops, 4 bottoms, 3 shoes in several colours, 9 hats,
accessories and held items, for both builds) and 20 ready-made characters. made_with_the_full_pack.gif shows the full
pack on Gridwright Isometric Tiles (sold separately).

TRY IT
  python compose.py --list
  python compose.py --character jogger --scale 2 --frames
  Layers\<build>\<group>\*.png: 8 rows (s, sw, w, nw, n, ne, e, se) x 54 columns of 64x64; layers.json
  gives each animation's first column, fps, loop, the feet point (32, 46) and the layer order.

LICENCE (the full text is in LICENSE.txt)
  Use and modify in personal and commercial projects. No resale or redistribution of the assets.
  Credit appreciated, not required. Not for AI training or NFTs.

HOW IT WAS MADE
  Every frame is drawn by code.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
