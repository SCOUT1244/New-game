"""Gridwright Isometric Character Creator - compose your own characters from the layer sheets.

Needs Python 3 and Pillow (pip install pillow). Run it from the pack's folder (where layers.json is):

    python compose.py --list                          what you can wear (styles and colours per build)
    python compose.py --character farmer             one of the 20 ready-made characters (Recipes/)
    python compose.py my_hero.json                   your own recipe (see Recipes/ for the format)
    python compose.py my_hero.json --scale 3 --frames --out Output

A recipe is JSON: {"name": "my_hero", "build": "broad",
                   "layers": [["body", "light"], ["top_tee", "red"], ["hair_short", "brown"]]}
Layers are drawn in the pack's fixed order (body, shoes, bottom, top, accessory, facial, hair, headwear, held),
whatever order the recipe lists them in. Use at most one style per group (two hats would cover each other).

It writes one sheet per animation (one row per direction: s, sw, w, nw, n, ne, e, se), a JSON with the frames,
fps and the feet point, and with --frames every frame as its own PNG.
"""
import argparse
import json
import sys
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent


def load_info(root=HERE):
    with open(root / 'layers.json', encoding='utf-8') as f:
        return json.load(f)


def group_of(info, style):
    return info['styles'][style]['group']


def compose_sheet(info, build, layers, root=HERE, cache=None):
    """The full layer sheet of a recipe (all animations side by side), as a Pillow RGBA image."""
    order = info['order']
    picked = sorted(layers, key=lambda q: order.index(group_of(info, q[0])))
    groups = [group_of(info, s) for s, _ in picked]
    if len(set(groups)) != len(groups):
        raise SystemExit(f'one style per group, please: {groups}')
    out = None
    for style, colour in picked:
        try:
            rel = info['layers'][build][style][colour]
        except KeyError:
            raise SystemExit(f'not in this pack: {build} {style} {colour} (python compose.py --list)')
        img = cache.get(rel) if cache is not None else None
        if img is None:
            img = Image.open(root / rel).convert('RGBA')
            if cache is not None:
                cache[rel] = img
        out = img.copy() if out is None else Image.alpha_composite(out, img)
    return out


def split(info, sheet):
    """Full sheet -> {animation: sheet of that animation}."""
    cw, ch = info['cell']
    out = {}
    for a in info['animations']:
        x0 = a['column'] * cw
        out[a['name']] = sheet.crop((x0, 0, x0 + a['frames'] * cw, ch * len(info['rows'])))
    return out


def write(info, name, build, layers, out_dir, scale=1, frames=False, root=HERE):
    sheet = compose_sheet(info, build, layers, root)
    cw, ch = info['cell']
    folder = Path(out_dir) / name
    folder.mkdir(parents=True, exist_ok=True)
    anims = {}
    parts = split(info, sheet)
    for a in info['animations']:
        s = parts[a['name']]
        if scale != 1:
            s = s.resize((s.width * scale, s.height * scale), Image.NEAREST)
        s.save(folder / f'{name}_{a["name"]}.png')
        anims[a['name']] = dict(image=f'{name}_{a["name"]}.png', frames=a['frames'], fps=a['fps'], loop=a['loop'])
        if frames:
            for r, d in enumerate(info['rows']):
                for i in range(a['frames']):
                    f = s.crop((i * cw * scale, r * ch * scale, (i + 1) * cw * scale, (r + 1) * ch * scale))
                    (folder / 'frames').mkdir(exist_ok=True)
                    f.save(folder / 'frames' / f'{name}_{a["name"]}_{d}_{i + 1:02d}.png')
    meta = dict(character=name, build=build, layers=[list(x) for x in layers], scale=scale,
                cell=[cw * scale, ch * scale], anchor=[v * scale for v in info['anchor']], rows=info['rows'],
                animations=anims)
    with open(folder / f'{name}.json', 'w', encoding='utf-8') as f:
        json.dump(meta, f, indent=1)
    return folder


def main(argv=None):
    ap = argparse.ArgumentParser(description='Compose Gridwright isometric characters from layers.')
    ap.add_argument('recipe', nargs='?', help='a recipe JSON file')
    ap.add_argument('--character', help='a ready-made character from Recipes/ (e.g. farmer)')
    ap.add_argument('--list', action='store_true', help='list builds, styles and colours')
    ap.add_argument('--scale', type=int, default=1, help='1, 2, 3 ... (nearest neighbour)')
    ap.add_argument('--frames', action='store_true', help='also write every frame as its own PNG')
    ap.add_argument('--out', default='Output', help='output folder (default: Output)')
    a = ap.parse_args(argv)
    info = load_info()
    if a.list:
        for build, styles in info['layers'].items():
            print(f'build "{build}":')
            for style, cols in styles.items():
                print(f'  {style:22s} {", ".join(cols)}')
        return
    if a.character:
        path = HERE / 'Recipes' / f'{a.character}.json'
    elif a.recipe:
        path = Path(a.recipe)
    else:
        ap.print_help()
        return
    with open(path, encoding='utf-8') as f:
        r = json.load(f)
    folder = write(info, r['name'], r['build'], [tuple(x) for x in r['layers']], a.out, a.scale, a.frames)
    print(f'wrote {folder}')


if __name__ == '__main__':
    main(sys.argv[1:])
