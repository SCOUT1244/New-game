GRIDWRIGHT ISOMETRIC CITY PEOPLE - FREE SAMPLE  v1.0
====================================================

A free taste of Gridwright Isometric City People: 3 of its 20 people (Man in a T-shirt, Woman in jeans, Police officer) with every
animation (idle, walk, phone) in all 8 directions, at 1x, 2x and 3x, with the same folders, names and characters.json
as the full pack, plus the shadow.

Licence: the same as the full pack (LICENSE.txt): use it in your games, commercial ones too; don't resell the files.
Made by code. No third-party art.

MORE GRIDWRIGHT
---------------
Every Gridwright pack in one bundle for $20: https://itch.io/s/207198
Need art made for your game? Order a custom pack: https://gridwright.store/custom
All Gridwright packs: https://gridwrightstudio.itch.io

Join the Gridwright Discord for new packs the day they come out, free assets, sales,
pack requests and help with these files:
https://discord.gg/CmXcSgBQ6V
